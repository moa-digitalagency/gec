--
-- PostgreSQL database dump
--

-- Dumped from database version 16.9 (84ade85)
-- Dumped by pg_dump version 17.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public."user" DROP CONSTRAINT IF EXISTS user_departement_id_fkey;
ALTER TABLE IF EXISTS ONLY public.type_courrier_sortant DROP CONSTRAINT IF EXISTS type_courrier_sortant_cree_par_id_fkey;
ALTER TABLE IF EXISTS ONLY public.role_permission DROP CONSTRAINT IF EXISTS role_permission_role_id_fkey;
ALTER TABLE IF EXISTS ONLY public.role_permission DROP CONSTRAINT IF EXISTS role_permission_accorde_par_id_fkey;
ALTER TABLE IF EXISTS ONLY public.role DROP CONSTRAINT IF EXISTS role_cree_par_id_fkey;
ALTER TABLE IF EXISTS ONLY public.parametres_systeme DROP CONSTRAINT IF EXISTS parametres_systeme_modifie_par_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notification DROP CONSTRAINT IF EXISTS notification_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notification DROP CONSTRAINT IF EXISTS notification_courrier_id_fkey;
ALTER TABLE IF EXISTS ONLY public.log_activite DROP CONSTRAINT IF EXISTS log_activite_utilisateur_id_fkey;
ALTER TABLE IF EXISTS ONLY public.log_activite DROP CONSTRAINT IF EXISTS log_activite_courrier_id_fkey;
ALTER TABLE IF EXISTS ONLY public.email_template DROP CONSTRAINT IF EXISTS email_template_modifie_par_id_fkey;
ALTER TABLE IF EXISTS ONLY public.email_template DROP CONSTRAINT IF EXISTS email_template_cree_par_id_fkey;
ALTER TABLE IF EXISTS ONLY public.departement DROP CONSTRAINT IF EXISTS departement_chef_departement_id_fkey;
ALTER TABLE IF EXISTS ONLY public.courrier DROP CONSTRAINT IF EXISTS courrier_utilisateur_id_fkey;
ALTER TABLE IF EXISTS ONLY public.courrier DROP CONSTRAINT IF EXISTS courrier_type_courrier_sortant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.courrier DROP CONSTRAINT IF EXISTS courrier_modifie_par_id_fkey;
ALTER TABLE IF EXISTS ONLY public.courrier_modification DROP CONSTRAINT IF EXISTS courrier_modification_utilisateur_id_fkey;
ALTER TABLE IF EXISTS ONLY public.courrier_modification DROP CONSTRAINT IF EXISTS courrier_modification_courrier_id_fkey;
ALTER TABLE IF EXISTS ONLY public.courrier_forward DROP CONSTRAINT IF EXISTS courrier_forward_forwarded_to_id_fkey;
ALTER TABLE IF EXISTS ONLY public.courrier_forward DROP CONSTRAINT IF EXISTS courrier_forward_forwarded_by_id_fkey;
ALTER TABLE IF EXISTS ONLY public.courrier_forward DROP CONSTRAINT IF EXISTS courrier_forward_courrier_id_fkey;
ALTER TABLE IF EXISTS ONLY public.courrier DROP CONSTRAINT IF EXISTS courrier_deleted_by_id_fkey;
ALTER TABLE IF EXISTS ONLY public.courrier_comment DROP CONSTRAINT IF EXISTS courrier_comment_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.courrier_comment DROP CONSTRAINT IF EXISTS courrier_comment_modifie_par_id_fkey;
ALTER TABLE IF EXISTS ONLY public.courrier_comment DROP CONSTRAINT IF EXISTS courrier_comment_courrier_id_fkey;
DROP INDEX IF EXISTS public.ix_user_username;
DROP INDEX IF EXISTS public.ix_user_role;
DROP INDEX IF EXISTS public.ix_user_nom_complet;
DROP INDEX IF EXISTS public.ix_user_email;
DROP INDEX IF EXISTS public.ix_user_departement_id;
DROP INDEX IF EXISTS public.ix_user_date_creation;
DROP INDEX IF EXISTS public.ix_user_actif;
DROP INDEX IF EXISTS public.ix_notification_user_id;
DROP INDEX IF EXISTS public.ix_notification_type_notification;
DROP INDEX IF EXISTS public.ix_notification_lu;
DROP INDEX IF EXISTS public.ix_notification_date_creation;
DROP INDEX IF EXISTS public.ix_notification_courrier_id;
DROP INDEX IF EXISTS public.ix_log_activite_utilisateur_id;
DROP INDEX IF EXISTS public.ix_log_activite_date_action;
DROP INDEX IF EXISTS public.ix_log_activite_courrier_id;
DROP INDEX IF EXISTS public.ix_log_activite_action;
DROP INDEX IF EXISTS public.ix_ip_whitelist_is_active;
DROP INDEX IF EXISTS public.ix_ip_whitelist_ip_address;
DROP INDEX IF EXISTS public.ix_ip_whitelist_created_at;
DROP INDEX IF EXISTS public.ix_ip_block_is_active;
DROP INDEX IF EXISTS public.ix_ip_block_ip_address;
DROP INDEX IF EXISTS public.ix_ip_block_expires_at;
DROP INDEX IF EXISTS public.ix_ip_block_blocked_at;
DROP INDEX IF EXISTS public.ix_courrier_type_courrier_sortant_id;
DROP INDEX IF EXISTS public.ix_courrier_type_courrier;
DROP INDEX IF EXISTS public.ix_courrier_statut;
DROP INDEX IF EXISTS public.ix_courrier_numero_reference;
DROP INDEX IF EXISTS public.ix_courrier_numero_accuse_reception;
DROP INDEX IF EXISTS public.ix_courrier_modification_utilisateur_id;
DROP INDEX IF EXISTS public.ix_courrier_modification_date_modification;
DROP INDEX IF EXISTS public.ix_courrier_modification_courrier_id;
DROP INDEX IF EXISTS public.ix_courrier_is_deleted;
DROP INDEX IF EXISTS public.ix_courrier_forward_lu;
DROP INDEX IF EXISTS public.ix_courrier_forward_forwarded_to_id;
DROP INDEX IF EXISTS public.ix_courrier_forward_forwarded_by_id;
DROP INDEX IF EXISTS public.ix_courrier_forward_email_sent;
DROP INDEX IF EXISTS public.ix_courrier_forward_date_transmission;
DROP INDEX IF EXISTS public.ix_courrier_forward_courrier_id;
DROP INDEX IF EXISTS public.ix_courrier_fichier_type;
DROP INDEX IF EXISTS public.ix_courrier_expediteur;
DROP INDEX IF EXISTS public.ix_courrier_destinataire;
DROP INDEX IF EXISTS public.ix_courrier_date_redaction;
DROP INDEX IF EXISTS public.ix_courrier_date_modification_statut;
DROP INDEX IF EXISTS public.ix_courrier_date_enregistrement;
DROP INDEX IF EXISTS public.ix_courrier_comment_user_id;
DROP INDEX IF EXISTS public.ix_courrier_comment_type_comment;
DROP INDEX IF EXISTS public.ix_courrier_comment_date_creation;
DROP INDEX IF EXISTS public.ix_courrier_comment_courrier_id;
DROP INDEX IF EXISTS public.ix_courrier_comment_actif;
ALTER TABLE IF EXISTS ONLY public."user" DROP CONSTRAINT IF EXISTS user_pkey;
ALTER TABLE IF EXISTS ONLY public."user" DROP CONSTRAINT IF EXISTS user_matricule_key;
ALTER TABLE IF EXISTS ONLY public.email_template DROP CONSTRAINT IF EXISTS unique_template_lang;
ALTER TABLE IF EXISTS ONLY public.type_courrier_sortant DROP CONSTRAINT IF EXISTS type_courrier_sortant_pkey;
ALTER TABLE IF EXISTS ONLY public.type_courrier_sortant DROP CONSTRAINT IF EXISTS type_courrier_sortant_nom_key;
ALTER TABLE IF EXISTS ONLY public.system_health DROP CONSTRAINT IF EXISTS system_health_pkey;
ALTER TABLE IF EXISTS ONLY public.statut_courrier DROP CONSTRAINT IF EXISTS statut_courrier_pkey;
ALTER TABLE IF EXISTS ONLY public.statut_courrier DROP CONSTRAINT IF EXISTS statut_courrier_nom_key;
ALTER TABLE IF EXISTS ONLY public.role DROP CONSTRAINT IF EXISTS role_pkey;
ALTER TABLE IF EXISTS ONLY public.role_permission DROP CONSTRAINT IF EXISTS role_permission_pkey;
ALTER TABLE IF EXISTS ONLY public.role DROP CONSTRAINT IF EXISTS role_nom_key;
ALTER TABLE IF EXISTS ONLY public.parametres_systeme DROP CONSTRAINT IF EXISTS parametres_systeme_pkey;
ALTER TABLE IF EXISTS ONLY public.notification DROP CONSTRAINT IF EXISTS notification_pkey;
ALTER TABLE IF EXISTS ONLY public.migration_log DROP CONSTRAINT IF EXISTS migration_log_pkey;
ALTER TABLE IF EXISTS ONLY public.log_activite DROP CONSTRAINT IF EXISTS log_activite_pkey;
ALTER TABLE IF EXISTS ONLY public.ip_whitelist DROP CONSTRAINT IF EXISTS ip_whitelist_pkey;
ALTER TABLE IF EXISTS ONLY public.ip_block DROP CONSTRAINT IF EXISTS ip_block_pkey;
ALTER TABLE IF EXISTS ONLY public.email_template DROP CONSTRAINT IF EXISTS email_template_pkey;
ALTER TABLE IF EXISTS ONLY public.departement DROP CONSTRAINT IF EXISTS departement_pkey;
ALTER TABLE IF EXISTS ONLY public.departement DROP CONSTRAINT IF EXISTS departement_nom_key;
ALTER TABLE IF EXISTS ONLY public.departement DROP CONSTRAINT IF EXISTS departement_code_key;
ALTER TABLE IF EXISTS ONLY public.courrier DROP CONSTRAINT IF EXISTS courrier_pkey;
ALTER TABLE IF EXISTS ONLY public.courrier_modification DROP CONSTRAINT IF EXISTS courrier_modification_pkey;
ALTER TABLE IF EXISTS ONLY public.courrier_forward DROP CONSTRAINT IF EXISTS courrier_forward_pkey;
ALTER TABLE IF EXISTS ONLY public.courrier_comment DROP CONSTRAINT IF EXISTS courrier_comment_pkey;
ALTER TABLE IF EXISTS public."user" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.type_courrier_sortant ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.system_health ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.statut_courrier ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.role_permission ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.role ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.parametres_systeme ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.notification ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.migration_log ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.log_activite ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.ip_whitelist ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.ip_block ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.email_template ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.departement ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.courrier_modification ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.courrier_forward ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.courrier_comment ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.courrier ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.user_id_seq;
DROP TABLE IF EXISTS public."user";
DROP SEQUENCE IF EXISTS public.type_courrier_sortant_id_seq;
DROP TABLE IF EXISTS public.type_courrier_sortant;
DROP SEQUENCE IF EXISTS public.system_health_id_seq;
DROP TABLE IF EXISTS public.system_health;
DROP SEQUENCE IF EXISTS public.statut_courrier_id_seq;
DROP TABLE IF EXISTS public.statut_courrier;
DROP SEQUENCE IF EXISTS public.role_permission_id_seq;
DROP TABLE IF EXISTS public.role_permission;
DROP SEQUENCE IF EXISTS public.role_id_seq;
DROP TABLE IF EXISTS public.role;
DROP SEQUENCE IF EXISTS public.parametres_systeme_id_seq;
DROP TABLE IF EXISTS public.parametres_systeme;
DROP SEQUENCE IF EXISTS public.notification_id_seq;
DROP TABLE IF EXISTS public.notification;
DROP SEQUENCE IF EXISTS public.migration_log_id_seq;
DROP TABLE IF EXISTS public.migration_log;
DROP SEQUENCE IF EXISTS public.log_activite_id_seq;
DROP TABLE IF EXISTS public.log_activite;
DROP SEQUENCE IF EXISTS public.ip_whitelist_id_seq;
DROP TABLE IF EXISTS public.ip_whitelist;
DROP SEQUENCE IF EXISTS public.ip_block_id_seq;
DROP TABLE IF EXISTS public.ip_block;
DROP SEQUENCE IF EXISTS public.email_template_id_seq;
DROP TABLE IF EXISTS public.email_template;
DROP SEQUENCE IF EXISTS public.departement_id_seq;
DROP TABLE IF EXISTS public.departement;
DROP SEQUENCE IF EXISTS public.courrier_modification_id_seq;
DROP TABLE IF EXISTS public.courrier_modification;
DROP SEQUENCE IF EXISTS public.courrier_id_seq;
DROP SEQUENCE IF EXISTS public.courrier_forward_id_seq;
DROP TABLE IF EXISTS public.courrier_forward;
DROP SEQUENCE IF EXISTS public.courrier_comment_id_seq;
DROP TABLE IF EXISTS public.courrier_comment;
DROP TABLE IF EXISTS public.courrier;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: courrier; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.courrier (
    id integer NOT NULL,
    numero_accuse_reception character varying(50) NOT NULL,
    numero_reference character varying(100),
    objet text NOT NULL,
    type_courrier character varying(20) NOT NULL,
    type_courrier_sortant_id integer,
    expediteur character varying(200),
    destinataire character varying(200),
    date_redaction date,
    date_enregistrement timestamp without time zone,
    autres_informations text,
    fichier_nom character varying(255),
    fichier_chemin character varying(500),
    fichier_type character varying(50),
    statut character varying(50) NOT NULL,
    date_modification_statut timestamp without time zone,
    secretaire_general_copie boolean,
    objet_encrypted text,
    expediteur_encrypted text,
    destinataire_encrypted text,
    numero_reference_encrypted text,
    fichier_checksum character varying(64),
    fichier_encrypted boolean,
    is_deleted boolean NOT NULL,
    deleted_at timestamp without time zone,
    deleted_by_id integer,
    utilisateur_id integer NOT NULL,
    modifie_par_id integer
);


ALTER TABLE public.courrier OWNER TO neondb_owner;

--
-- Name: courrier_comment; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.courrier_comment (
    id integer NOT NULL,
    courrier_id integer NOT NULL,
    user_id integer NOT NULL,
    commentaire text NOT NULL,
    type_comment character varying(50),
    date_creation timestamp without time zone,
    date_modification timestamp without time zone,
    modifie_par_id integer,
    actif boolean
);


ALTER TABLE public.courrier_comment OWNER TO neondb_owner;

--
-- Name: courrier_comment_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.courrier_comment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.courrier_comment_id_seq OWNER TO neondb_owner;

--
-- Name: courrier_comment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.courrier_comment_id_seq OWNED BY public.courrier_comment.id;


--
-- Name: courrier_forward; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.courrier_forward (
    id integer NOT NULL,
    courrier_id integer NOT NULL,
    forwarded_by_id integer NOT NULL,
    forwarded_to_id integer NOT NULL,
    message text,
    date_transmission timestamp without time zone,
    lu boolean,
    date_lecture timestamp without time zone,
    email_sent boolean
);


ALTER TABLE public.courrier_forward OWNER TO neondb_owner;

--
-- Name: courrier_forward_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.courrier_forward_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.courrier_forward_id_seq OWNER TO neondb_owner;

--
-- Name: courrier_forward_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.courrier_forward_id_seq OWNED BY public.courrier_forward.id;


--
-- Name: courrier_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.courrier_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.courrier_id_seq OWNER TO neondb_owner;

--
-- Name: courrier_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.courrier_id_seq OWNED BY public.courrier.id;


--
-- Name: courrier_modification; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.courrier_modification (
    id integer NOT NULL,
    courrier_id integer NOT NULL,
    utilisateur_id integer NOT NULL,
    champ_modifie character varying(100) NOT NULL,
    ancienne_valeur text,
    nouvelle_valeur text,
    date_modification timestamp without time zone,
    ip_address character varying(45)
);


ALTER TABLE public.courrier_modification OWNER TO neondb_owner;

--
-- Name: courrier_modification_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.courrier_modification_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.courrier_modification_id_seq OWNER TO neondb_owner;

--
-- Name: courrier_modification_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.courrier_modification_id_seq OWNED BY public.courrier_modification.id;


--
-- Name: departement; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.departement (
    id integer NOT NULL,
    nom character varying(100) NOT NULL,
    description text,
    code character varying(10) NOT NULL,
    chef_departement_id integer,
    actif boolean,
    date_creation timestamp without time zone
);


ALTER TABLE public.departement OWNER TO neondb_owner;

--
-- Name: departement_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.departement_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.departement_id_seq OWNER TO neondb_owner;

--
-- Name: departement_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.departement_id_seq OWNED BY public.departement.id;


--
-- Name: email_template; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.email_template (
    id integer NOT NULL,
    type_template character varying(50) NOT NULL,
    langue character varying(5) NOT NULL,
    sujet character varying(200) NOT NULL,
    contenu_html text NOT NULL,
    contenu_texte text,
    actif boolean NOT NULL,
    date_creation timestamp without time zone,
    date_modification timestamp without time zone,
    cree_par_id integer NOT NULL,
    modifie_par_id integer
);


ALTER TABLE public.email_template OWNER TO neondb_owner;

--
-- Name: email_template_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.email_template_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.email_template_id_seq OWNER TO neondb_owner;

--
-- Name: email_template_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.email_template_id_seq OWNED BY public.email_template.id;


--
-- Name: ip_block; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.ip_block (
    id integer NOT NULL,
    ip_address character varying(45) NOT NULL,
    reason character varying(200) NOT NULL,
    blocked_at timestamp without time zone,
    expires_at timestamp without time zone NOT NULL,
    created_by character varying(100),
    is_active boolean
);


ALTER TABLE public.ip_block OWNER TO neondb_owner;

--
-- Name: ip_block_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.ip_block_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ip_block_id_seq OWNER TO neondb_owner;

--
-- Name: ip_block_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.ip_block_id_seq OWNED BY public.ip_block.id;


--
-- Name: ip_whitelist; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.ip_whitelist (
    id integer NOT NULL,
    ip_address character varying(45) NOT NULL,
    description character varying(200),
    created_at timestamp without time zone,
    created_by character varying(100) NOT NULL,
    is_active boolean
);


ALTER TABLE public.ip_whitelist OWNER TO neondb_owner;

--
-- Name: ip_whitelist_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.ip_whitelist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ip_whitelist_id_seq OWNER TO neondb_owner;

--
-- Name: ip_whitelist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.ip_whitelist_id_seq OWNED BY public.ip_whitelist.id;


--
-- Name: log_activite; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.log_activite (
    id integer NOT NULL,
    action character varying(100) NOT NULL,
    description text,
    date_action timestamp without time zone,
    ip_address character varying(45),
    utilisateur_id integer NOT NULL,
    courrier_id integer
);


ALTER TABLE public.log_activite OWNER TO neondb_owner;

--
-- Name: log_activite_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.log_activite_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.log_activite_id_seq OWNER TO neondb_owner;

--
-- Name: log_activite_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.log_activite_id_seq OWNED BY public.log_activite.id;


--
-- Name: migration_log; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.migration_log (
    id integer NOT NULL,
    migration_name character varying(255) NOT NULL,
    applied_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    version character varying(50)
);


ALTER TABLE public.migration_log OWNER TO neondb_owner;

--
-- Name: migration_log_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.migration_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.migration_log_id_seq OWNER TO neondb_owner;

--
-- Name: migration_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.migration_log_id_seq OWNED BY public.migration_log.id;


--
-- Name: notification; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.notification (
    id integer NOT NULL,
    user_id integer NOT NULL,
    type_notification character varying(50) NOT NULL,
    titre character varying(200) NOT NULL,
    message text NOT NULL,
    courrier_id integer,
    lu boolean,
    date_creation timestamp without time zone,
    date_lecture timestamp without time zone
);


ALTER TABLE public.notification OWNER TO neondb_owner;

--
-- Name: notification_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.notification_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notification_id_seq OWNER TO neondb_owner;

--
-- Name: notification_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.notification_id_seq OWNED BY public.notification.id;


--
-- Name: parametres_systeme; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.parametres_systeme (
    id integer NOT NULL,
    nom_logiciel character varying(100) NOT NULL,
    logo_url character varying(500),
    mode_numero_accuse character varying(20) NOT NULL,
    format_numero_accuse character varying(50) NOT NULL,
    adresse_organisme text,
    telephone character varying(20),
    email_contact character varying(120),
    texte_footer text,
    copyright_crypte character varying(500) NOT NULL,
    logo_pdf character varying(500),
    titre_pdf character varying(200),
    sous_titre_pdf character varying(200),
    pays_pdf character varying(200),
    copyright_text text,
    date_modification timestamp without time zone,
    modifie_par_id integer,
    smtp_server character varying(200),
    smtp_port integer DEFAULT 587,
    smtp_use_tls boolean DEFAULT true,
    smtp_username character varying(200),
    smtp_password character varying(500),
    appellation_departement character varying(100) DEFAULT 'Départements'::character varying NOT NULL,
    email_provider character varying(20) DEFAULT 'sendgrid'::character varying,
    notify_superadmin_new_mail boolean DEFAULT true NOT NULL,
    sendgrid_api_key character varying(500),
    notification_templates text,
    backup_settings text,
    theme_settings text,
    titre_responsable_structure character varying(100) DEFAULT 'Secrétaire Général'::character varying
);


ALTER TABLE public.parametres_systeme OWNER TO neondb_owner;

--
-- Name: parametres_systeme_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.parametres_systeme_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.parametres_systeme_id_seq OWNER TO neondb_owner;

--
-- Name: parametres_systeme_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.parametres_systeme_id_seq OWNED BY public.parametres_systeme.id;


--
-- Name: role; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.role (
    id integer NOT NULL,
    nom character varying(50) NOT NULL,
    nom_affichage character varying(100) NOT NULL,
    description text,
    couleur character varying(50) NOT NULL,
    icone character varying(50) NOT NULL,
    actif boolean,
    modifiable boolean,
    date_creation timestamp without time zone,
    date_modification timestamp without time zone,
    cree_par_id integer
);


ALTER TABLE public.role OWNER TO neondb_owner;

--
-- Name: role_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.role_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.role_id_seq OWNER TO neondb_owner;

--
-- Name: role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.role_id_seq OWNED BY public.role.id;


--
-- Name: role_permission; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.role_permission (
    id integer NOT NULL,
    role_id integer NOT NULL,
    permission_nom character varying(100) NOT NULL,
    date_creation timestamp without time zone,
    accorde_par_id integer
);


ALTER TABLE public.role_permission OWNER TO neondb_owner;

--
-- Name: role_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.role_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.role_permission_id_seq OWNER TO neondb_owner;

--
-- Name: role_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.role_permission_id_seq OWNED BY public.role_permission.id;


--
-- Name: statut_courrier; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.statut_courrier (
    id integer NOT NULL,
    nom character varying(50) NOT NULL,
    description character varying(200),
    couleur character varying(50) NOT NULL,
    actif boolean,
    ordre integer,
    date_creation timestamp without time zone
);


ALTER TABLE public.statut_courrier OWNER TO neondb_owner;

--
-- Name: statut_courrier_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.statut_courrier_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.statut_courrier_id_seq OWNER TO neondb_owner;

--
-- Name: statut_courrier_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.statut_courrier_id_seq OWNED BY public.statut_courrier.id;


--
-- Name: system_health; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.system_health (
    id integer NOT NULL,
    check_name character varying(255) NOT NULL,
    status character varying(50) NOT NULL,
    last_check timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    details text
);


ALTER TABLE public.system_health OWNER TO neondb_owner;

--
-- Name: system_health_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.system_health_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.system_health_id_seq OWNER TO neondb_owner;

--
-- Name: system_health_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.system_health_id_seq OWNED BY public.system_health.id;


--
-- Name: type_courrier_sortant; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.type_courrier_sortant (
    id integer NOT NULL,
    nom character varying(100) NOT NULL,
    description text,
    actif boolean NOT NULL,
    ordre_affichage integer,
    date_creation timestamp without time zone,
    cree_par_id integer
);


ALTER TABLE public.type_courrier_sortant OWNER TO neondb_owner;

--
-- Name: type_courrier_sortant_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.type_courrier_sortant_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.type_courrier_sortant_id_seq OWNER TO neondb_owner;

--
-- Name: type_courrier_sortant_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.type_courrier_sortant_id_seq OWNED BY public.type_courrier_sortant.id;


--
-- Name: user; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public."user" (
    id integer NOT NULL,
    username character varying(64) NOT NULL,
    email character varying(120) NOT NULL,
    nom_complet character varying(120) NOT NULL,
    password_hash character varying(256) NOT NULL,
    date_creation timestamp without time zone,
    actif boolean,
    role character varying(20) NOT NULL,
    langue character varying(5) NOT NULL,
    photo_profile character varying(255),
    departement_id integer,
    matricule character varying(50),
    fonction character varying(200),
    email_encrypted text,
    nom_complet_encrypted text,
    matricule_encrypted text,
    fonction_encrypted text,
    password_hash_encrypted text
);


ALTER TABLE public."user" OWNER TO neondb_owner;

--
-- Name: user_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_id_seq OWNER TO neondb_owner;

--
-- Name: user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.user_id_seq OWNED BY public."user".id;


--
-- Name: courrier id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.courrier ALTER COLUMN id SET DEFAULT nextval('public.courrier_id_seq'::regclass);


--
-- Name: courrier_comment id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.courrier_comment ALTER COLUMN id SET DEFAULT nextval('public.courrier_comment_id_seq'::regclass);


--
-- Name: courrier_forward id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.courrier_forward ALTER COLUMN id SET DEFAULT nextval('public.courrier_forward_id_seq'::regclass);


--
-- Name: courrier_modification id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.courrier_modification ALTER COLUMN id SET DEFAULT nextval('public.courrier_modification_id_seq'::regclass);


--
-- Name: departement id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.departement ALTER COLUMN id SET DEFAULT nextval('public.departement_id_seq'::regclass);


--
-- Name: email_template id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.email_template ALTER COLUMN id SET DEFAULT nextval('public.email_template_id_seq'::regclass);


--
-- Name: ip_block id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.ip_block ALTER COLUMN id SET DEFAULT nextval('public.ip_block_id_seq'::regclass);


--
-- Name: ip_whitelist id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.ip_whitelist ALTER COLUMN id SET DEFAULT nextval('public.ip_whitelist_id_seq'::regclass);


--
-- Name: log_activite id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.log_activite ALTER COLUMN id SET DEFAULT nextval('public.log_activite_id_seq'::regclass);


--
-- Name: migration_log id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.migration_log ALTER COLUMN id SET DEFAULT nextval('public.migration_log_id_seq'::regclass);


--
-- Name: notification id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.notification ALTER COLUMN id SET DEFAULT nextval('public.notification_id_seq'::regclass);


--
-- Name: parametres_systeme id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.parametres_systeme ALTER COLUMN id SET DEFAULT nextval('public.parametres_systeme_id_seq'::regclass);


--
-- Name: role id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.role ALTER COLUMN id SET DEFAULT nextval('public.role_id_seq'::regclass);


--
-- Name: role_permission id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.role_permission ALTER COLUMN id SET DEFAULT nextval('public.role_permission_id_seq'::regclass);


--
-- Name: statut_courrier id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.statut_courrier ALTER COLUMN id SET DEFAULT nextval('public.statut_courrier_id_seq'::regclass);


--
-- Name: system_health id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.system_health ALTER COLUMN id SET DEFAULT nextval('public.system_health_id_seq'::regclass);


--
-- Name: type_courrier_sortant id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.type_courrier_sortant ALTER COLUMN id SET DEFAULT nextval('public.type_courrier_sortant_id_seq'::regclass);


--
-- Name: user id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public."user" ALTER COLUMN id SET DEFAULT nextval('public.user_id_seq'::regclass);


--
-- Data for Name: courrier; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.courrier (id, numero_accuse_reception, numero_reference, objet, type_courrier, type_courrier_sortant_id, expediteur, destinataire, date_redaction, date_enregistrement, autres_informations, fichier_nom, fichier_chemin, fichier_type, statut, date_modification_statut, secretaire_general_copie, objet_encrypted, expediteur_encrypted, destinataire_encrypted, numero_reference_encrypted, fichier_checksum, fichier_encrypted, is_deleted, deleted_at, deleted_by_id, utilisateur_id, modifie_par_id) FROM stdin;
\.


--
-- Data for Name: courrier_comment; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.courrier_comment (id, courrier_id, user_id, commentaire, type_comment, date_creation, date_modification, modifie_par_id, actif) FROM stdin;
\.


--
-- Data for Name: courrier_forward; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.courrier_forward (id, courrier_id, forwarded_by_id, forwarded_to_id, message, date_transmission, lu, date_lecture, email_sent) FROM stdin;
\.


--
-- Data for Name: courrier_modification; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.courrier_modification (id, courrier_id, utilisateur_id, champ_modifie, ancienne_valeur, nouvelle_valeur, date_modification, ip_address) FROM stdin;
\.


--
-- Data for Name: departement; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.departement (id, nom, description, code, chef_departement_id, actif, date_creation) FROM stdin;
1	Administration Générale	Administration générale et ressources humaines	ADM	\N	t	2025-08-29 15:51:27.983504
2	Département Juridique	Affaires juridiques et contentieux	JUR	\N	t	2025-08-29 15:51:27.983508
3	Département Technique	Études techniques et supervision	TECH	\N	t	2025-08-29 15:51:27.983509
4	Département Financier	Gestion financière et comptabilité	FIN	\N	t	2025-08-29 15:51:27.983509
5	Secrétariat Général	Secrétariat général et courrier	SG	\N	t	2025-08-29 15:51:27.98351
\.


--
-- Data for Name: email_template; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.email_template (id, type_template, langue, sujet, contenu_html, contenu_texte, actif, date_creation, date_modification, cree_par_id, modifie_par_id) FROM stdin;
1	new_mail	fr	Nouveau courrier enregistré - {{numero_accuse_reception}}	<!DOCTYPE html>\n<html>\n<head>\n    <meta charset="UTF-8">\n    <style>\n        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }\n        .header { background-color: #003087; color: white; padding: 20px; text-align: center; }\n        .content { padding: 20px; }\n        .details { background-color: #f8f9fa; padding: 15px; border-radius: 5px; margin: 10px 0; }\n        .footer { background-color: #f1f1f1; padding: 10px; text-align: center; font-size: 12px; }\n    </style>\n</head>\n<body>\n    <div class="header">\n        <h2>GEC - Notification de Nouveau Courrier</h2>\n    </div>\n    <div class="content">\n        <p>Bonjour,</p>\n        <p>Un nouveau courrier a été enregistré dans le système GEC.</p>\n        \n        <div class="details">\n            <h3>Détails du courrier :</h3>\n            <p><strong>Numéro d'accusé de réception :</strong> {{numero_accuse_reception}}</p>\n            <p><strong>Type :</strong> {{type_courrier}}</p>\n            <p><strong>Objet :</strong> {{objet}}</p>\n            <p><strong>Expéditeur :</strong> {{expediteur}}</p>\n            <p><strong>Date d'enregistrement :</strong> {{date_enregistrement}}</p>\n            <p><strong>Enregistré par :</strong> {{created_by}}</p>\n        </div>\n        \n        <p>Vous pouvez consulter ce courrier en vous connectant au système GEC.</p>\n    </div>\n    <div class="footer">\n        <p>GEC - Système de Gestion du Courrier<br>\n        Secrétariat Général - République Démocratique du Congo</p>\n    </div>\n</body>\n</html>	GEC - Notification de Nouveau Courrier\n\nUn nouveau courrier a été enregistré dans le système.\n\nDétails du courrier :\n- Numéro d'accusé de réception : {{numero_accuse_reception}}\n- Type : {{type_courrier}}\n- Objet : {{objet}}\n- Expéditeur : {{expediteur}}\n- Date d'enregistrement : {{date_enregistrement}}\n- Enregistré par : {{created_by}}\n\nConnectez-vous au système GEC pour consulter ce courrier.\n\nGEC - Système de Gestion du Courrier\nSecrétariat Général - République Démocratique du Congo	t	2025-08-30 02:50:28.549194	2025-08-30 02:50:28.549197	1	\N
2	mail_forwarded	fr	Courrier transmis - {{numero_accuse_reception}}	<!DOCTYPE html>\n<html>\n<head>\n    <meta charset="UTF-8">\n    <style>\n        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }\n        .header { background-color: #009639; color: white; padding: 20px; text-align: center; }\n        .content { padding: 20px; }\n        .details { background-color: #f8f9fa; padding: 15px; border-radius: 5px; margin: 10px 0; }\n        .footer { background-color: #f1f1f1; padding: 10px; text-align: center; font-size: 12px; }\n    </style>\n</head>\n<body>\n    <div class="header">\n        <h2>GEC - Courrier Transmis</h2>\n    </div>\n    <div class="content">\n        <p>Bonjour,</p>\n        <p>Un courrier vous a été transmis par <strong>{{transmis_par}}</strong>.</p>\n        \n        <div class="details">\n            <h3>Détails du courrier :</h3>\n            <p><strong>Numéro d'accusé de réception :</strong> {{numero_accuse_reception}}</p>\n            <p><strong>Type :</strong> {{type_courrier}}</p>\n            <p><strong>Objet :</strong> {{objet}}</p>\n            <p><strong>Expéditeur :</strong> {{expediteur}}</p>\n            <p><strong>Date de transmission :</strong> {{date_reception}}</p>\n        </div>\n        \n        <p>Veuillez vous connecter au système GEC pour consulter ce courrier.</p>\n    </div>\n    <div class="footer">\n        <p>GEC - Système de Gestion du Courrier<br>\n        Secrétariat Général - République Démocratique du Congo</p>\n    </div>\n</body>\n</html>	GEC - Courrier Transmis\n\nUn courrier vous a été transmis par {{transmis_par}}.\n\nDétails du courrier :\n- Numéro d'accusé de réception : {{numero_accuse_reception}}\n- Type : {{type_courrier}}\n- Objet : {{objet}}\n- Expéditeur : {{expediteur}}\n- Date de transmission : {{date_reception}}\n\nConnectez-vous au système GEC pour consulter ce courrier.\n\nGEC - Système de Gestion du Courrier\nSecrétariat Général - République Démocratique du Congo	t	2025-08-30 02:50:28.628718	2025-08-30 02:50:28.628724	1	\N
\.


--
-- Data for Name: ip_block; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.ip_block (id, ip_address, reason, blocked_at, expires_at, created_by, is_active) FROM stdin;
\.


--
-- Data for Name: ip_whitelist; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.ip_whitelist (id, ip_address, description, created_at, created_by, is_active) FROM stdin;
\.


--
-- Data for Name: log_activite; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.log_activite (id, action, description, date_action, ip_address, utilisateur_id, courrier_id) FROM stdin;
\.


--
-- Data for Name: migration_log; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.migration_log (id, migration_name, applied_at, version) FROM stdin;
\.


--
-- Data for Name: notification; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.notification (id, user_id, type_notification, titre, message, courrier_id, lu, date_creation, date_lecture) FROM stdin;
\.


--
-- Data for Name: parametres_systeme; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.parametres_systeme (id, nom_logiciel, logo_url, mode_numero_accuse, format_numero_accuse, adresse_organisme, telephone, email_contact, texte_footer, copyright_crypte, logo_pdf, titre_pdf, sous_titre_pdf, pays_pdf, copyright_text, date_modification, modifie_par_id, smtp_server, smtp_port, smtp_use_tls, smtp_username, smtp_password, appellation_departement, email_provider, notify_superadmin_new_mail, sendgrid_api_key, notification_templates, backup_settings, theme_settings, titre_responsable_structure) FROM stdin;
1	GEC - Mines RDC	\N	automatique	GEC-{year}-{counter:05d}	\N	\N	moa.myoneart@gmail.com	Système de Gestion Électronique du Courrier	wqkgMjAyNSBHRUMuIE1hZGUgd2l0aCDwn5KWIGFuZCDimJUgQnkgTU9BLURpZ2l0YWwgQWdlbmN5IExMQw==	\N	Ministère des Mines	Secrétariat Général	République Démocratique du Congo	© 2025 GEC. Made with 💖 and ☕ By MOA-Digital Agency LLC	2025-08-30 18:25:26.680791	1	monbusiness.pro	465	t	notif@monbusiness.pro	Pjjg8ldUOk9hNBwnIf0emrjY5zx0fGMhqsjuatMHC/M=	Divisions	sendgrid	f	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	\N	\N	\N	Directeur Général
\.


--
-- Data for Name: role; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.role (id, nom, nom_affichage, description, couleur, icone, actif, modifiable, date_creation, date_modification, cree_par_id) FROM stdin;
1	super_admin	Super Administrateur	Accès complet au système avec toutes les permissions	bg-yellow-100 text-yellow-800	fas fa-crown	t	f	2025-08-29 15:51:27.395529	2025-08-29 15:51:27.395533	\N
2	admin	Administrateur	Gestion des utilisateurs et configuration système limitée	bg-blue-100 text-blue-800	fas fa-shield-alt	t	t	2025-08-29 15:51:27.395535	2025-08-29 15:51:27.395535	\N
3	user	Utilisateur	Accès de base pour enregistrer et consulter les courriers	bg-gray-100 text-gray-800	fas fa-user	t	t	2025-08-29 15:51:27.395536	2025-08-29 15:51:27.395536	\N
4	role_teste	Role teste	Role teste	bg-red-100 text-red-800	fas fa-key	t	t	2025-08-29 16:08:09.85872	2025-08-29 16:08:09.858724	1
\.


--
-- Data for Name: role_permission; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.role_permission (id, role_id, permission_nom, date_creation, accorde_par_id) FROM stdin;
1	1	manage_users	2025-08-29 15:51:27.62797	\N
2	1	manage_roles	2025-08-29 15:51:27.627974	\N
3	1	manage_system_settings	2025-08-29 15:51:27.627975	\N
4	1	view_all_logs	2025-08-29 15:51:27.627975	\N
5	1	manage_statuses	2025-08-29 15:51:27.627976	\N
6	1	manage_departments	2025-08-29 15:51:27.627977	\N
7	1	register_mail	2025-08-29 15:51:27.627977	\N
8	1	view_mail	2025-08-29 15:51:27.627978	\N
9	1	search_mail	2025-08-29 15:51:27.627978	\N
10	1	export_data	2025-08-29 15:51:27.627979	\N
11	1	delete_mail	2025-08-29 15:51:27.627979	\N
12	1	view_trash	2025-08-29 15:51:27.62798	\N
13	1	restore_mail	2025-08-29 15:51:27.62798	\N
14	1	view_all	2025-08-29 15:51:27.627981	\N
15	1	edit_all	2025-08-29 15:51:27.627981	\N
16	1	read_all_mail	2025-08-29 15:51:27.627982	\N
17	1	manage_updates	2025-08-29 15:51:27.627982	\N
18	1	manage_backup	2025-08-29 15:51:27.627983	\N
19	2	manage_statuses	2025-08-29 15:51:27.707806	\N
20	2	register_mail	2025-08-29 15:51:27.707809	\N
21	2	view_mail	2025-08-29 15:51:27.70781	\N
22	2	search_mail	2025-08-29 15:51:27.70781	\N
23	2	export_data	2025-08-29 15:51:27.707811	\N
24	2	manage_system_settings	2025-08-29 15:51:27.707811	\N
25	2	view_department	2025-08-29 15:51:27.707812	\N
26	2	edit_department	2025-08-29 15:51:27.707812	\N
27	2	read_department_mail	2025-08-29 15:51:27.707812	\N
28	3	register_mail	2025-08-29 15:51:27.790274	\N
29	3	view_mail	2025-08-29 15:51:27.790277	\N
30	3	search_mail	2025-08-29 15:51:27.790278	\N
31	3	export_data	2025-08-29 15:51:27.790278	\N
32	3	view_own	2025-08-29 15:51:27.790279	\N
33	3	edit_own	2025-08-29 15:51:27.790279	\N
34	3	read_own_mail	2025-08-29 15:51:27.79028	\N
35	4	manage_security_settings	2025-08-29 16:08:09.904424	1
36	4	manage_statuses	2025-08-29 16:08:09.904432	1
37	4	register_mail	2025-08-29 16:08:09.904433	1
38	4	view_mail	2025-08-29 16:08:09.904433	1
39	4	search_mail	2025-08-29 16:08:09.904434	1
40	4	export_data	2025-08-29 16:08:09.904435	1
41	4	delete_mail	2025-08-29 16:08:09.904435	1
42	4	view_trash	2025-08-29 16:08:09.904436	1
43	4	restore_mail	2025-08-29 16:08:09.904436	1
44	4	read_all_mail	2025-08-29 16:08:09.904437	1
45	4	read_department_mail	2025-08-29 16:08:09.904438	1
46	4	read_own_mail	2025-08-29 16:08:09.904438	1
47	4	manage_updates	2025-08-29 16:08:09.904439	1
48	4	manage_backup	2025-08-29 16:08:09.904439	1
49	1	manage_email_templates	\N	\N
50	2	manage_email_templates	\N	\N
\.


--
-- Data for Name: statut_courrier; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.statut_courrier (id, nom, description, couleur, actif, ordre, date_creation) FROM stdin;
1	RECU	Courrier reçu	bg-blue-100 text-blue-800	t	1	2025-08-29 15:51:26.902202
2	EN_COURS	En cours de traitement	bg-yellow-100 text-yellow-800	t	2	2025-08-29 15:51:26.976759
3	TRAITE	Traité	bg-green-100 text-green-800	t	3	2025-08-29 15:51:27.052542
4	ARCHIVE	Archivé	bg-gray-100 text-gray-800	t	4	2025-08-29 15:51:27.128018
5	URGENT	Urgent	bg-red-100 text-red-800	t	0	2025-08-29 15:51:27.202978
\.


--
-- Data for Name: system_health; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.system_health (id, check_name, status, last_check, details) FROM stdin;
\.


--
-- Data for Name: type_courrier_sortant; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.type_courrier_sortant (id, nom, description, actif, ordre_affichage, date_creation, cree_par_id) FROM stdin;
1	Note circulaire	Note circulaire à diffusion large	t	1	2025-08-29 15:51:28.180194	\N
2	Note télégramme	Note télégramme urgente	t	2	2025-08-29 15:51:28.180198	\N
3	Lettre officielle	Lettre officielle standard	t	3	2025-08-29 15:51:28.180198	\N
4	Mémorandum	Mémorandum interne	t	4	2025-08-29 15:51:28.180199	\N
5	Convocation	Convocation à une réunion ou événement	t	5	2025-08-29 15:51:28.1802	\N
6	Rapport	Rapport officiel	t	6	2025-08-29 15:51:28.1802	\N
7	Note de service	Note de service interne	t	7	2025-08-29 15:51:28.180201	\N
8	Autre	Autre type de courrier sortant	t	99	2025-08-29 15:51:28.180202	\N
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public."user" (id, username, email, nom_complet, password_hash, date_creation, actif, role, langue, photo_profile, departement_id, matricule, fonction, email_encrypted, nom_complet_encrypted, matricule_encrypted, fonction_encrypted, password_hash_encrypted) FROM stdin;
1	sa.gec001	admin@mines.gov.cd	Administrateur Système	scrypt:32768:8:1$hYRECTy7aQ0EvOcS$a605aa462ff9930d86dcdd5ada0f8eaf99e561f7292d458f88882d1281f88cc2a683f173506194583e4a3873f21c600dbc5ca82ba45d3a4faaafcf785ff1933d	2025-08-29 15:51:26.500423	t	super_admin	fr	\N	\N	\N	\N	\N	\N	\N	\N	\N
2	superadmin2	moa.myoneart@gmail.com	Administrateur 2	scrypt:32768:8:1$D77EXYSIg8cBiBkT$eafc2ccf4400d573c6c2ddb79431ad3848524fbfdad28a40e52aeb72a3f49f0b3cb8906bba829771d7b76a137575d1ee1313f4728685404fe2480482f643892d	2025-08-30 11:00:32.905697	t	admin	fr	\N	1	\N	\N	\N	\N	\N	\N	\N
3	usertest	aisancekalonji@gmail.com	Kalonji	scrypt:32768:8:1$C2Y3FdD1hSK6furM$15aeb7a65d8ea3af7748d8e1eee575d6662c0954620f74d03841d6414a33447771f5dcb66e9d1b5f3caad4ad969e473c75bc2b39de3c3e7c4d6be8c1dc7003ce	2025-08-30 11:01:18.012017	t	user	fr	\N	1	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Name: courrier_comment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.courrier_comment_id_seq', 1, true);


--
-- Name: courrier_forward_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.courrier_forward_id_seq', 1, false);


--
-- Name: courrier_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.courrier_id_seq', 1, false);


--
-- Name: courrier_modification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.courrier_modification_id_seq', 1, false);


--
-- Name: departement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.departement_id_seq', 5, true);


--
-- Name: email_template_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.email_template_id_seq', 2, true);


--
-- Name: ip_block_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.ip_block_id_seq', 1, false);


--
-- Name: ip_whitelist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.ip_whitelist_id_seq', 1, false);


--
-- Name: log_activite_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.log_activite_id_seq', 45, true);


--
-- Name: migration_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.migration_log_id_seq', 1, false);


--
-- Name: notification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.notification_id_seq', 1, true);


--
-- Name: parametres_systeme_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.parametres_systeme_id_seq', 1, true);


--
-- Name: role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.role_id_seq', 4, true);


--
-- Name: role_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.role_permission_id_seq', 50, true);


--
-- Name: statut_courrier_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.statut_courrier_id_seq', 5, true);


--
-- Name: system_health_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.system_health_id_seq', 1, false);


--
-- Name: type_courrier_sortant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.type_courrier_sortant_id_seq', 8, true);


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.user_id_seq', 3, true);


--
-- Name: courrier_comment courrier_comment_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.courrier_comment
    ADD CONSTRAINT courrier_comment_pkey PRIMARY KEY (id);


--
-- Name: courrier_forward courrier_forward_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.courrier_forward
    ADD CONSTRAINT courrier_forward_pkey PRIMARY KEY (id);


--
-- Name: courrier_modification courrier_modification_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.courrier_modification
    ADD CONSTRAINT courrier_modification_pkey PRIMARY KEY (id);


--
-- Name: courrier courrier_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.courrier
    ADD CONSTRAINT courrier_pkey PRIMARY KEY (id);


--
-- Name: departement departement_code_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.departement
    ADD CONSTRAINT departement_code_key UNIQUE (code);


--
-- Name: departement departement_nom_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.departement
    ADD CONSTRAINT departement_nom_key UNIQUE (nom);


--
-- Name: departement departement_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.departement
    ADD CONSTRAINT departement_pkey PRIMARY KEY (id);


--
-- Name: email_template email_template_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.email_template
    ADD CONSTRAINT email_template_pkey PRIMARY KEY (id);


--
-- Name: ip_block ip_block_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.ip_block
    ADD CONSTRAINT ip_block_pkey PRIMARY KEY (id);


--
-- Name: ip_whitelist ip_whitelist_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.ip_whitelist
    ADD CONSTRAINT ip_whitelist_pkey PRIMARY KEY (id);


--
-- Name: log_activite log_activite_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.log_activite
    ADD CONSTRAINT log_activite_pkey PRIMARY KEY (id);


--
-- Name: migration_log migration_log_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.migration_log
    ADD CONSTRAINT migration_log_pkey PRIMARY KEY (id);


--
-- Name: notification notification_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT notification_pkey PRIMARY KEY (id);


--
-- Name: parametres_systeme parametres_systeme_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.parametres_systeme
    ADD CONSTRAINT parametres_systeme_pkey PRIMARY KEY (id);


--
-- Name: role role_nom_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT role_nom_key UNIQUE (nom);


--
-- Name: role_permission role_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.role_permission
    ADD CONSTRAINT role_permission_pkey PRIMARY KEY (id);


--
-- Name: role role_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT role_pkey PRIMARY KEY (id);


--
-- Name: statut_courrier statut_courrier_nom_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.statut_courrier
    ADD CONSTRAINT statut_courrier_nom_key UNIQUE (nom);


--
-- Name: statut_courrier statut_courrier_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.statut_courrier
    ADD CONSTRAINT statut_courrier_pkey PRIMARY KEY (id);


--
-- Name: system_health system_health_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.system_health
    ADD CONSTRAINT system_health_pkey PRIMARY KEY (id);


--
-- Name: type_courrier_sortant type_courrier_sortant_nom_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.type_courrier_sortant
    ADD CONSTRAINT type_courrier_sortant_nom_key UNIQUE (nom);


--
-- Name: type_courrier_sortant type_courrier_sortant_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.type_courrier_sortant
    ADD CONSTRAINT type_courrier_sortant_pkey PRIMARY KEY (id);


--
-- Name: email_template unique_template_lang; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.email_template
    ADD CONSTRAINT unique_template_lang UNIQUE (type_template, langue);


--
-- Name: user user_matricule_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_matricule_key UNIQUE (matricule);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: ix_courrier_comment_actif; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_courrier_comment_actif ON public.courrier_comment USING btree (actif);


--
-- Name: ix_courrier_comment_courrier_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_courrier_comment_courrier_id ON public.courrier_comment USING btree (courrier_id);


--
-- Name: ix_courrier_comment_date_creation; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_courrier_comment_date_creation ON public.courrier_comment USING btree (date_creation);


--
-- Name: ix_courrier_comment_type_comment; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_courrier_comment_type_comment ON public.courrier_comment USING btree (type_comment);


--
-- Name: ix_courrier_comment_user_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_courrier_comment_user_id ON public.courrier_comment USING btree (user_id);


--
-- Name: ix_courrier_date_enregistrement; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_courrier_date_enregistrement ON public.courrier USING btree (date_enregistrement);


--
-- Name: ix_courrier_date_modification_statut; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_courrier_date_modification_statut ON public.courrier USING btree (date_modification_statut);


--
-- Name: ix_courrier_date_redaction; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_courrier_date_redaction ON public.courrier USING btree (date_redaction);


--
-- Name: ix_courrier_destinataire; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_courrier_destinataire ON public.courrier USING btree (destinataire);


--
-- Name: ix_courrier_expediteur; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_courrier_expediteur ON public.courrier USING btree (expediteur);


--
-- Name: ix_courrier_fichier_type; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_courrier_fichier_type ON public.courrier USING btree (fichier_type);


--
-- Name: ix_courrier_forward_courrier_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_courrier_forward_courrier_id ON public.courrier_forward USING btree (courrier_id);


--
-- Name: ix_courrier_forward_date_transmission; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_courrier_forward_date_transmission ON public.courrier_forward USING btree (date_transmission);


--
-- Name: ix_courrier_forward_email_sent; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_courrier_forward_email_sent ON public.courrier_forward USING btree (email_sent);


--
-- Name: ix_courrier_forward_forwarded_by_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_courrier_forward_forwarded_by_id ON public.courrier_forward USING btree (forwarded_by_id);


--
-- Name: ix_courrier_forward_forwarded_to_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_courrier_forward_forwarded_to_id ON public.courrier_forward USING btree (forwarded_to_id);


--
-- Name: ix_courrier_forward_lu; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_courrier_forward_lu ON public.courrier_forward USING btree (lu);


--
-- Name: ix_courrier_is_deleted; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_courrier_is_deleted ON public.courrier USING btree (is_deleted);


--
-- Name: ix_courrier_modification_courrier_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_courrier_modification_courrier_id ON public.courrier_modification USING btree (courrier_id);


--
-- Name: ix_courrier_modification_date_modification; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_courrier_modification_date_modification ON public.courrier_modification USING btree (date_modification);


--
-- Name: ix_courrier_modification_utilisateur_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_courrier_modification_utilisateur_id ON public.courrier_modification USING btree (utilisateur_id);


--
-- Name: ix_courrier_numero_accuse_reception; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX ix_courrier_numero_accuse_reception ON public.courrier USING btree (numero_accuse_reception);


--
-- Name: ix_courrier_numero_reference; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_courrier_numero_reference ON public.courrier USING btree (numero_reference);


--
-- Name: ix_courrier_statut; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_courrier_statut ON public.courrier USING btree (statut);


--
-- Name: ix_courrier_type_courrier; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_courrier_type_courrier ON public.courrier USING btree (type_courrier);


--
-- Name: ix_courrier_type_courrier_sortant_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_courrier_type_courrier_sortant_id ON public.courrier USING btree (type_courrier_sortant_id);


--
-- Name: ix_ip_block_blocked_at; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_ip_block_blocked_at ON public.ip_block USING btree (blocked_at);


--
-- Name: ix_ip_block_expires_at; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_ip_block_expires_at ON public.ip_block USING btree (expires_at);


--
-- Name: ix_ip_block_ip_address; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX ix_ip_block_ip_address ON public.ip_block USING btree (ip_address);


--
-- Name: ix_ip_block_is_active; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_ip_block_is_active ON public.ip_block USING btree (is_active);


--
-- Name: ix_ip_whitelist_created_at; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_ip_whitelist_created_at ON public.ip_whitelist USING btree (created_at);


--
-- Name: ix_ip_whitelist_ip_address; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX ix_ip_whitelist_ip_address ON public.ip_whitelist USING btree (ip_address);


--
-- Name: ix_ip_whitelist_is_active; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_ip_whitelist_is_active ON public.ip_whitelist USING btree (is_active);


--
-- Name: ix_log_activite_action; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_log_activite_action ON public.log_activite USING btree (action);


--
-- Name: ix_log_activite_courrier_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_log_activite_courrier_id ON public.log_activite USING btree (courrier_id);


--
-- Name: ix_log_activite_date_action; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_log_activite_date_action ON public.log_activite USING btree (date_action);


--
-- Name: ix_log_activite_utilisateur_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_log_activite_utilisateur_id ON public.log_activite USING btree (utilisateur_id);


--
-- Name: ix_notification_courrier_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_notification_courrier_id ON public.notification USING btree (courrier_id);


--
-- Name: ix_notification_date_creation; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_notification_date_creation ON public.notification USING btree (date_creation);


--
-- Name: ix_notification_lu; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_notification_lu ON public.notification USING btree (lu);


--
-- Name: ix_notification_type_notification; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_notification_type_notification ON public.notification USING btree (type_notification);


--
-- Name: ix_notification_user_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_notification_user_id ON public.notification USING btree (user_id);


--
-- Name: ix_user_actif; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_user_actif ON public."user" USING btree (actif);


--
-- Name: ix_user_date_creation; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_user_date_creation ON public."user" USING btree (date_creation);


--
-- Name: ix_user_departement_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_user_departement_id ON public."user" USING btree (departement_id);


--
-- Name: ix_user_email; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX ix_user_email ON public."user" USING btree (email);


--
-- Name: ix_user_nom_complet; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_user_nom_complet ON public."user" USING btree (nom_complet);


--
-- Name: ix_user_role; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_user_role ON public."user" USING btree (role);


--
-- Name: ix_user_username; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX ix_user_username ON public."user" USING btree (username);


--
-- Name: courrier_comment courrier_comment_courrier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.courrier_comment
    ADD CONSTRAINT courrier_comment_courrier_id_fkey FOREIGN KEY (courrier_id) REFERENCES public.courrier(id);


--
-- Name: courrier_comment courrier_comment_modifie_par_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.courrier_comment
    ADD CONSTRAINT courrier_comment_modifie_par_id_fkey FOREIGN KEY (modifie_par_id) REFERENCES public."user"(id);


--
-- Name: courrier_comment courrier_comment_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.courrier_comment
    ADD CONSTRAINT courrier_comment_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: courrier courrier_deleted_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.courrier
    ADD CONSTRAINT courrier_deleted_by_id_fkey FOREIGN KEY (deleted_by_id) REFERENCES public."user"(id);


--
-- Name: courrier_forward courrier_forward_courrier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.courrier_forward
    ADD CONSTRAINT courrier_forward_courrier_id_fkey FOREIGN KEY (courrier_id) REFERENCES public.courrier(id);


--
-- Name: courrier_forward courrier_forward_forwarded_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.courrier_forward
    ADD CONSTRAINT courrier_forward_forwarded_by_id_fkey FOREIGN KEY (forwarded_by_id) REFERENCES public."user"(id);


--
-- Name: courrier_forward courrier_forward_forwarded_to_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.courrier_forward
    ADD CONSTRAINT courrier_forward_forwarded_to_id_fkey FOREIGN KEY (forwarded_to_id) REFERENCES public."user"(id);


--
-- Name: courrier_modification courrier_modification_courrier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.courrier_modification
    ADD CONSTRAINT courrier_modification_courrier_id_fkey FOREIGN KEY (courrier_id) REFERENCES public.courrier(id);


--
-- Name: courrier_modification courrier_modification_utilisateur_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.courrier_modification
    ADD CONSTRAINT courrier_modification_utilisateur_id_fkey FOREIGN KEY (utilisateur_id) REFERENCES public."user"(id);


--
-- Name: courrier courrier_modifie_par_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.courrier
    ADD CONSTRAINT courrier_modifie_par_id_fkey FOREIGN KEY (modifie_par_id) REFERENCES public."user"(id);


--
-- Name: courrier courrier_type_courrier_sortant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.courrier
    ADD CONSTRAINT courrier_type_courrier_sortant_id_fkey FOREIGN KEY (type_courrier_sortant_id) REFERENCES public.type_courrier_sortant(id);


--
-- Name: courrier courrier_utilisateur_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.courrier
    ADD CONSTRAINT courrier_utilisateur_id_fkey FOREIGN KEY (utilisateur_id) REFERENCES public."user"(id);


--
-- Name: departement departement_chef_departement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.departement
    ADD CONSTRAINT departement_chef_departement_id_fkey FOREIGN KEY (chef_departement_id) REFERENCES public."user"(id);


--
-- Name: email_template email_template_cree_par_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.email_template
    ADD CONSTRAINT email_template_cree_par_id_fkey FOREIGN KEY (cree_par_id) REFERENCES public."user"(id);


--
-- Name: email_template email_template_modifie_par_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.email_template
    ADD CONSTRAINT email_template_modifie_par_id_fkey FOREIGN KEY (modifie_par_id) REFERENCES public."user"(id);


--
-- Name: log_activite log_activite_courrier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.log_activite
    ADD CONSTRAINT log_activite_courrier_id_fkey FOREIGN KEY (courrier_id) REFERENCES public.courrier(id);


--
-- Name: log_activite log_activite_utilisateur_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.log_activite
    ADD CONSTRAINT log_activite_utilisateur_id_fkey FOREIGN KEY (utilisateur_id) REFERENCES public."user"(id);


--
-- Name: notification notification_courrier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT notification_courrier_id_fkey FOREIGN KEY (courrier_id) REFERENCES public.courrier(id);


--
-- Name: notification notification_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT notification_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: parametres_systeme parametres_systeme_modifie_par_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.parametres_systeme
    ADD CONSTRAINT parametres_systeme_modifie_par_id_fkey FOREIGN KEY (modifie_par_id) REFERENCES public."user"(id);


--
-- Name: role role_cree_par_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT role_cree_par_id_fkey FOREIGN KEY (cree_par_id) REFERENCES public."user"(id);


--
-- Name: role_permission role_permission_accorde_par_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.role_permission
    ADD CONSTRAINT role_permission_accorde_par_id_fkey FOREIGN KEY (accorde_par_id) REFERENCES public."user"(id);


--
-- Name: role_permission role_permission_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.role_permission
    ADD CONSTRAINT role_permission_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.role(id);


--
-- Name: type_courrier_sortant type_courrier_sortant_cree_par_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.type_courrier_sortant
    ADD CONSTRAINT type_courrier_sortant_cree_par_id_fkey FOREIGN KEY (cree_par_id) REFERENCES public."user"(id);


--
-- Name: user user_departement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_departement_id_fkey FOREIGN KEY (departement_id) REFERENCES public.departement(id);


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO neon_superuser WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLES TO neon_superuser WITH GRANT OPTION;


--
-- PostgreSQL database dump complete
--

