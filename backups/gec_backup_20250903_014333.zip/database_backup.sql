--
-- PostgreSQL database dump
--

-- Dumped from database version 16.9 (84ade85)
-- Dumped by pg_dump version 17.5

-- Started on 2025-09-03 01:43:33 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE IF EXISTS neondb;
--
-- TOC entry 3599 (class 1262 OID 16389)
-- Name: neondb; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE neondb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C.UTF-8';


\connect neondb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 228 (class 1259 OID 16562)
-- Name: courrier; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.courrier (
    id integer NOT NULL,
    numero_accuse_reception character varying(50) NOT NULL,
    numero_reference character varying(100),
    objet text NOT NULL,
    type_courrier character varying(20) NOT NULL,
    type_courrier_sortant_id integer,
    expediteur character varying(200),
    destinataire character varying(200),
    date_redaction date,
    date_enregistrement timestamp without time zone,
    autres_informations text,
    fichier_nom character varying(255),
    fichier_chemin character varying(500),
    fichier_type character varying(50),
    statut character varying(50) NOT NULL,
    date_modification_statut timestamp without time zone,
    secretaire_general_copie boolean,
    objet_encrypted text,
    expediteur_encrypted text,
    destinataire_encrypted text,
    numero_reference_encrypted text,
    fichier_checksum character varying(64),
    fichier_encrypted boolean,
    is_deleted boolean NOT NULL,
    deleted_at timestamp without time zone,
    deleted_by_id integer,
    utilisateur_id integer NOT NULL,
    modifie_par_id integer
);


--
-- TOC entry 240 (class 1259 OID 32793)
-- Name: courrier_comment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.courrier_comment (
    id integer NOT NULL,
    courrier_id integer NOT NULL,
    user_id integer NOT NULL,
    commentaire text NOT NULL,
    type_comment character varying(50),
    date_creation timestamp without time zone,
    date_modification timestamp without time zone,
    modifie_par_id integer,
    actif boolean
);


--
-- TOC entry 239 (class 1259 OID 32792)
-- Name: courrier_comment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.courrier_comment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3600 (class 0 OID 0)
-- Dependencies: 239
-- Name: courrier_comment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.courrier_comment_id_seq OWNED BY public.courrier_comment.id;


--
-- TOC entry 242 (class 1259 OID 32822)
-- Name: courrier_forward; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.courrier_forward (
    id integer NOT NULL,
    courrier_id integer NOT NULL,
    forwarded_by_id integer NOT NULL,
    forwarded_to_id integer NOT NULL,
    message text,
    date_transmission timestamp without time zone,
    lu boolean,
    date_lecture timestamp without time zone,
    email_sent boolean
);


--
-- TOC entry 241 (class 1259 OID 32821)
-- Name: courrier_forward_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.courrier_forward_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3601 (class 0 OID 0)
-- Dependencies: 241
-- Name: courrier_forward_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.courrier_forward_id_seq OWNED BY public.courrier_forward.id;


--
-- TOC entry 227 (class 1259 OID 16561)
-- Name: courrier_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.courrier_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3602 (class 0 OID 0)
-- Dependencies: 227
-- Name: courrier_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.courrier_id_seq OWNED BY public.courrier.id;


--
-- TOC entry 232 (class 1259 OID 16620)
-- Name: courrier_modification; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.courrier_modification (
    id integer NOT NULL,
    courrier_id integer NOT NULL,
    utilisateur_id integer NOT NULL,
    champ_modifie character varying(100) NOT NULL,
    ancienne_valeur text,
    nouvelle_valeur text,
    date_modification timestamp without time zone,
    ip_address character varying(45)
);


--
-- TOC entry 231 (class 1259 OID 16619)
-- Name: courrier_modification_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.courrier_modification_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3603 (class 0 OID 0)
-- Dependencies: 231
-- Name: courrier_modification_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.courrier_modification_id_seq OWNED BY public.courrier_modification.id;


--
-- TOC entry 216 (class 1259 OID 16476)
-- Name: departement; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.departement (
    id integer NOT NULL,
    nom character varying(100) NOT NULL,
    description text,
    code character varying(10) NOT NULL,
    chef_departement_id integer,
    actif boolean,
    date_creation timestamp without time zone
);


--
-- TOC entry 215 (class 1259 OID 16475)
-- Name: departement_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.departement_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3604 (class 0 OID 0)
-- Dependencies: 215
-- Name: departement_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.departement_id_seq OWNED BY public.departement.id;


--
-- TOC entry 244 (class 1259 OID 65537)
-- Name: email_template; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_template (
    id integer NOT NULL,
    type_template character varying(50) NOT NULL,
    langue character varying(5) NOT NULL,
    sujet character varying(200) NOT NULL,
    contenu_html text NOT NULL,
    contenu_texte text,
    actif boolean NOT NULL,
    date_creation timestamp without time zone,
    date_modification timestamp without time zone,
    cree_par_id integer NOT NULL,
    modifie_par_id integer
);


--
-- TOC entry 243 (class 1259 OID 65536)
-- Name: email_template_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.email_template_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3605 (class 0 OID 0)
-- Dependencies: 243
-- Name: email_template_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.email_template_id_seq OWNED BY public.email_template.id;


--
-- TOC entry 236 (class 1259 OID 24577)
-- Name: ip_block; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ip_block (
    id integer NOT NULL,
    ip_address character varying(45) NOT NULL,
    reason character varying(200) NOT NULL,
    blocked_at timestamp without time zone,
    expires_at timestamp without time zone NOT NULL,
    created_by character varying(100),
    is_active boolean
);


--
-- TOC entry 235 (class 1259 OID 24576)
-- Name: ip_block_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ip_block_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3606 (class 0 OID 0)
-- Dependencies: 235
-- Name: ip_block_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ip_block_id_seq OWNED BY public.ip_block.id;


--
-- TOC entry 250 (class 1259 OID 114689)
-- Name: ip_whitelist; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ip_whitelist (
    id integer NOT NULL,
    ip_address character varying(45) NOT NULL,
    description character varying(200),
    created_at timestamp without time zone,
    created_by character varying(100) NOT NULL,
    is_active boolean
);


--
-- TOC entry 249 (class 1259 OID 114688)
-- Name: ip_whitelist_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ip_whitelist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3607 (class 0 OID 0)
-- Dependencies: 249
-- Name: ip_whitelist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ip_whitelist_id_seq OWNED BY public.ip_whitelist.id;


--
-- TOC entry 234 (class 1259 OID 16642)
-- Name: log_activite; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.log_activite (
    id integer NOT NULL,
    action character varying(100) NOT NULL,
    description text,
    date_action timestamp without time zone,
    ip_address character varying(45),
    utilisateur_id integer NOT NULL,
    courrier_id integer
);


--
-- TOC entry 233 (class 1259 OID 16641)
-- Name: log_activite_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.log_activite_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3608 (class 0 OID 0)
-- Dependencies: 233
-- Name: log_activite_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.log_activite_id_seq OWNED BY public.log_activite.id;


--
-- TOC entry 246 (class 1259 OID 106497)
-- Name: migration_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.migration_log (
    id integer NOT NULL,
    migration_name character varying(255) NOT NULL,
    applied_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    version character varying(50)
);


--
-- TOC entry 245 (class 1259 OID 106496)
-- Name: migration_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.migration_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3609 (class 0 OID 0)
-- Dependencies: 245
-- Name: migration_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.migration_log_id_seq OWNED BY public.migration_log.id;


--
-- TOC entry 238 (class 1259 OID 32769)
-- Name: notification; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification (
    id integer NOT NULL,
    user_id integer NOT NULL,
    type_notification character varying(50) NOT NULL,
    titre character varying(200) NOT NULL,
    message text NOT NULL,
    courrier_id integer,
    lu boolean,
    date_creation timestamp without time zone,
    date_lecture timestamp without time zone
);


--
-- TOC entry 237 (class 1259 OID 32768)
-- Name: notification_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notification_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3610 (class 0 OID 0)
-- Dependencies: 237
-- Name: notification_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notification_id_seq OWNED BY public.notification.id;


--
-- TOC entry 224 (class 1259 OID 16532)
-- Name: parametres_systeme; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parametres_systeme (
    id integer NOT NULL,
    nom_logiciel character varying(100) NOT NULL,
    logo_url character varying(500),
    mode_numero_accuse character varying(20) NOT NULL,
    format_numero_accuse character varying(50) NOT NULL,
    adresse_organisme text,
    telephone character varying(20),
    email_contact character varying(120),
    texte_footer text,
    copyright_crypte character varying(500) NOT NULL,
    logo_pdf character varying(500),
    titre_pdf character varying(200),
    sous_titre_pdf character varying(200),
    pays_pdf character varying(200),
    copyright_text text,
    date_modification timestamp without time zone,
    modifie_par_id integer,
    smtp_server character varying(200),
    smtp_port integer DEFAULT 587,
    smtp_use_tls boolean DEFAULT true,
    smtp_username character varying(200),
    smtp_password character varying(500),
    appellation_departement character varying(100) DEFAULT 'Départements'::character varying NOT NULL,
    email_provider character varying(20) DEFAULT 'sendgrid'::character varying,
    notify_superadmin_new_mail boolean DEFAULT true NOT NULL,
    sendgrid_api_key character varying(500),
    notification_templates text,
    backup_settings text,
    theme_settings text,
    titre_responsable_structure character varying(100) DEFAULT 'Secrétaire Général'::character varying
);


--
-- TOC entry 223 (class 1259 OID 16531)
-- Name: parametres_systeme_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.parametres_systeme_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3611 (class 0 OID 0)
-- Dependencies: 223
-- Name: parametres_systeme_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.parametres_systeme_id_seq OWNED BY public.parametres_systeme.id;


--
-- TOC entry 226 (class 1259 OID 16546)
-- Name: role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role (
    id integer NOT NULL,
    nom character varying(50) NOT NULL,
    nom_affichage character varying(100) NOT NULL,
    description text,
    couleur character varying(50) NOT NULL,
    icone character varying(50) NOT NULL,
    actif boolean,
    modifiable boolean,
    date_creation timestamp without time zone,
    date_modification timestamp without time zone,
    cree_par_id integer
);


--
-- TOC entry 225 (class 1259 OID 16545)
-- Name: role_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.role_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3612 (class 0 OID 0)
-- Dependencies: 225
-- Name: role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.role_id_seq OWNED BY public.role.id;


--
-- TOC entry 230 (class 1259 OID 16603)
-- Name: role_permission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_permission (
    id integer NOT NULL,
    role_id integer NOT NULL,
    permission_nom character varying(100) NOT NULL,
    date_creation timestamp without time zone,
    accorde_par_id integer
);


--
-- TOC entry 229 (class 1259 OID 16602)
-- Name: role_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.role_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3613 (class 0 OID 0)
-- Dependencies: 229
-- Name: role_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.role_permission_id_seq OWNED BY public.role_permission.id;


--
-- TOC entry 220 (class 1259 OID 16507)
-- Name: statut_courrier; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.statut_courrier (
    id integer NOT NULL,
    nom character varying(50) NOT NULL,
    description character varying(200),
    couleur character varying(50) NOT NULL,
    actif boolean,
    ordre integer,
    date_creation timestamp without time zone
);


--
-- TOC entry 219 (class 1259 OID 16506)
-- Name: statut_courrier_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.statut_courrier_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3614 (class 0 OID 0)
-- Dependencies: 219
-- Name: statut_courrier_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.statut_courrier_id_seq OWNED BY public.statut_courrier.id;


--
-- TOC entry 248 (class 1259 OID 106515)
-- Name: system_health; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_health (
    id integer NOT NULL,
    check_name character varying(255) NOT NULL,
    status character varying(50) NOT NULL,
    last_check timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    details text
);


--
-- TOC entry 247 (class 1259 OID 106514)
-- Name: system_health_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.system_health_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3615 (class 0 OID 0)
-- Dependencies: 247
-- Name: system_health_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.system_health_id_seq OWNED BY public.system_health.id;


--
-- TOC entry 222 (class 1259 OID 16516)
-- Name: type_courrier_sortant; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.type_courrier_sortant (
    id integer NOT NULL,
    nom character varying(100) NOT NULL,
    description text,
    actif boolean NOT NULL,
    ordre_affichage integer,
    date_creation timestamp without time zone,
    cree_par_id integer
);


--
-- TOC entry 221 (class 1259 OID 16515)
-- Name: type_courrier_sortant_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.type_courrier_sortant_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3616 (class 0 OID 0)
-- Dependencies: 221
-- Name: type_courrier_sortant_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.type_courrier_sortant_id_seq OWNED BY public.type_courrier_sortant.id;


--
-- TOC entry 218 (class 1259 OID 16489)
-- Name: user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."user" (
    id integer NOT NULL,
    username character varying(64) NOT NULL,
    email character varying(120) NOT NULL,
    nom_complet character varying(120) NOT NULL,
    password_hash character varying(256) NOT NULL,
    date_creation timestamp without time zone,
    actif boolean,
    role character varying(20) NOT NULL,
    langue character varying(5) NOT NULL,
    photo_profile character varying(255),
    departement_id integer,
    matricule character varying(50),
    fonction character varying(200),
    email_encrypted text,
    nom_complet_encrypted text,
    matricule_encrypted text,
    fonction_encrypted text,
    password_hash_encrypted text
);


--
-- TOC entry 217 (class 1259 OID 16488)
-- Name: user_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3617 (class 0 OID 0)
-- Dependencies: 217
-- Name: user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_id_seq OWNED BY public."user".id;


--
-- TOC entry 3277 (class 2604 OID 16565)
-- Name: courrier id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courrier ALTER COLUMN id SET DEFAULT nextval('public.courrier_id_seq'::regclass);


--
-- TOC entry 3283 (class 2604 OID 32796)
-- Name: courrier_comment id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courrier_comment ALTER COLUMN id SET DEFAULT nextval('public.courrier_comment_id_seq'::regclass);


--
-- TOC entry 3284 (class 2604 OID 32825)
-- Name: courrier_forward id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courrier_forward ALTER COLUMN id SET DEFAULT nextval('public.courrier_forward_id_seq'::regclass);


--
-- TOC entry 3279 (class 2604 OID 16623)
-- Name: courrier_modification id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courrier_modification ALTER COLUMN id SET DEFAULT nextval('public.courrier_modification_id_seq'::regclass);


--
-- TOC entry 3265 (class 2604 OID 16479)
-- Name: departement id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departement ALTER COLUMN id SET DEFAULT nextval('public.departement_id_seq'::regclass);


--
-- TOC entry 3285 (class 2604 OID 65540)
-- Name: email_template id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_template ALTER COLUMN id SET DEFAULT nextval('public.email_template_id_seq'::regclass);


--
-- TOC entry 3281 (class 2604 OID 24580)
-- Name: ip_block id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ip_block ALTER COLUMN id SET DEFAULT nextval('public.ip_block_id_seq'::regclass);


--
-- TOC entry 3290 (class 2604 OID 114692)
-- Name: ip_whitelist id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ip_whitelist ALTER COLUMN id SET DEFAULT nextval('public.ip_whitelist_id_seq'::regclass);


--
-- TOC entry 3280 (class 2604 OID 16645)
-- Name: log_activite id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.log_activite ALTER COLUMN id SET DEFAULT nextval('public.log_activite_id_seq'::regclass);


--
-- TOC entry 3286 (class 2604 OID 106500)
-- Name: migration_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migration_log ALTER COLUMN id SET DEFAULT nextval('public.migration_log_id_seq'::regclass);


--
-- TOC entry 3282 (class 2604 OID 32772)
-- Name: notification id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification ALTER COLUMN id SET DEFAULT nextval('public.notification_id_seq'::regclass);


--
-- TOC entry 3269 (class 2604 OID 16535)
-- Name: parametres_systeme id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parametres_systeme ALTER COLUMN id SET DEFAULT nextval('public.parametres_systeme_id_seq'::regclass);


--
-- TOC entry 3276 (class 2604 OID 16549)
-- Name: role id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role ALTER COLUMN id SET DEFAULT nextval('public.role_id_seq'::regclass);


--
-- TOC entry 3278 (class 2604 OID 16606)
-- Name: role_permission id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permission ALTER COLUMN id SET DEFAULT nextval('public.role_permission_id_seq'::regclass);


--
-- TOC entry 3267 (class 2604 OID 16510)
-- Name: statut_courrier id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.statut_courrier ALTER COLUMN id SET DEFAULT nextval('public.statut_courrier_id_seq'::regclass);


--
-- TOC entry 3288 (class 2604 OID 106518)
-- Name: system_health id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_health ALTER COLUMN id SET DEFAULT nextval('public.system_health_id_seq'::regclass);


--
-- TOC entry 3268 (class 2604 OID 16519)
-- Name: type_courrier_sortant id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.type_courrier_sortant ALTER COLUMN id SET DEFAULT nextval('public.type_courrier_sortant_id_seq'::regclass);


--
-- TOC entry 3266 (class 2604 OID 16492)
-- Name: user id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."user" ALTER COLUMN id SET DEFAULT nextval('public.user_id_seq'::regclass);


--
-- TOC entry 3571 (class 0 OID 16562)
-- Dependencies: 228
-- Data for Name: courrier; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.courrier (id, numero_accuse_reception, numero_reference, objet, type_courrier, type_courrier_sortant_id, expediteur, destinataire, date_redaction, date_enregistrement, autres_informations, fichier_nom, fichier_chemin, fichier_type, statut, date_modification_statut, secretaire_general_copie, objet_encrypted, expediteur_encrypted, destinataire_encrypted, numero_reference_encrypted, fichier_checksum, fichier_encrypted, is_deleted, deleted_at, deleted_by_id, utilisateur_id, modifie_par_id) FROM stdin;
\.


--
-- TOC entry 3583 (class 0 OID 32793)
-- Dependencies: 240
-- Data for Name: courrier_comment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.courrier_comment (id, courrier_id, user_id, commentaire, type_comment, date_creation, date_modification, modifie_par_id, actif) FROM stdin;
\.


--
-- TOC entry 3585 (class 0 OID 32822)
-- Dependencies: 242
-- Data for Name: courrier_forward; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.courrier_forward (id, courrier_id, forwarded_by_id, forwarded_to_id, message, date_transmission, lu, date_lecture, email_sent) FROM stdin;
\.


--
-- TOC entry 3575 (class 0 OID 16620)
-- Dependencies: 232
-- Data for Name: courrier_modification; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.courrier_modification (id, courrier_id, utilisateur_id, champ_modifie, ancienne_valeur, nouvelle_valeur, date_modification, ip_address) FROM stdin;
\.


--
-- TOC entry 3559 (class 0 OID 16476)
-- Dependencies: 216
-- Data for Name: departement; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.departement (id, nom, description, code, chef_departement_id, actif, date_creation) FROM stdin;
1	Administration Générale	Administration générale et ressources humaines	ADM	\N	t	2025-08-29 15:51:27.983504
2	Département Juridique	Affaires juridiques et contentieux	JUR	\N	t	2025-08-29 15:51:27.983508
3	Département Technique	Études techniques et supervision	TECH	\N	t	2025-08-29 15:51:27.983509
4	Département Financier	Gestion financière et comptabilité	FIN	\N	t	2025-08-29 15:51:27.983509
5	Secrétariat Général	Secrétariat général et courrier	SG	\N	t	2025-08-29 15:51:27.98351
\.


--
-- TOC entry 3587 (class 0 OID 65537)
-- Dependencies: 244
-- Data for Name: email_template; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_template (id, type_template, langue, sujet, contenu_html, contenu_texte, actif, date_creation, date_modification, cree_par_id, modifie_par_id) FROM stdin;
1	new_mail	fr	Nouveau courrier enregistré - {{numero_accuse_reception}}	<!DOCTYPE html>\n<html>\n<head>\n    <meta charset="UTF-8">\n    <style>\n        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }\n        .header { background-color: #003087; color: white; padding: 20px; text-align: center; }\n        .content { padding: 20px; }\n        .details { background-color: #f8f9fa; padding: 15px; border-radius: 5px; margin: 10px 0; }\n        .footer { background-color: #f1f1f1; padding: 10px; text-align: center; font-size: 12px; }\n    </style>\n</head>\n<body>\n    <div class="header">\n        <h2>GEC - Notification de Nouveau Courrier</h2>\n    </div>\n    <div class="content">\n        <p>Bonjour,</p>\n        <p>Un nouveau courrier a été enregistré dans le système GEC.</p>\n        \n        <div class="details">\n            <h3>Détails du courrier :</h3>\n            <p><strong>Numéro d'accusé de réception :</strong> {{numero_accuse_reception}}</p>\n            <p><strong>Type :</strong> {{type_courrier}}</p>\n            <p><strong>Objet :</strong> {{objet}}</p>\n            <p><strong>Expéditeur :</strong> {{expediteur}}</p>\n            <p><strong>Date d'enregistrement :</strong> {{date_enregistrement}}</p>\n            <p><strong>Enregistré par :</strong> {{created_by}}</p>\n        </div>\n        \n        <p>Vous pouvez consulter ce courrier en vous connectant au système GEC.</p>\n    </div>\n    <div class="footer">\n        <p>GEC - Système de Gestion du Courrier<br>\n        Secrétariat Général - République Démocratique du Congo</p>\n    </div>\n</body>\n</html>	GEC - Notification de Nouveau Courrier\n\nUn nouveau courrier a été enregistré dans le système.\n\nDétails du courrier :\n- Numéro d'accusé de réception : {{numero_accuse_reception}}\n- Type : {{type_courrier}}\n- Objet : {{objet}}\n- Expéditeur : {{expediteur}}\n- Date d'enregistrement : {{date_enregistrement}}\n- Enregistré par : {{created_by}}\n\nConnectez-vous au système GEC pour consulter ce courrier.\n\nGEC - Système de Gestion du Courrier\nSecrétariat Général - République Démocratique du Congo	t	2025-08-30 02:50:28.549194	2025-08-30 02:50:28.549197	1	\N
2	mail_forwarded	fr	Courrier transmis - {{numero_accuse_reception}}	<!DOCTYPE html>\n<html>\n<head>\n    <meta charset="UTF-8">\n    <style>\n        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }\n        .header { background-color: #009639; color: white; padding: 20px; text-align: center; }\n        .content { padding: 20px; }\n        .details { background-color: #f8f9fa; padding: 15px; border-radius: 5px; margin: 10px 0; }\n        .footer { background-color: #f1f1f1; padding: 10px; text-align: center; font-size: 12px; }\n    </style>\n</head>\n<body>\n    <div class="header">\n        <h2>GEC - Courrier Transmis</h2>\n    </div>\n    <div class="content">\n        <p>Bonjour,</p>\n        <p>Un courrier vous a été transmis par <strong>{{transmis_par}}</strong>.</p>\n        \n        <div class="details">\n            <h3>Détails du courrier :</h3>\n            <p><strong>Numéro d'accusé de réception :</strong> {{numero_accuse_reception}}</p>\n            <p><strong>Type :</strong> {{type_courrier}}</p>\n            <p><strong>Objet :</strong> {{objet}}</p>\n            <p><strong>Expéditeur :</strong> {{expediteur}}</p>\n            <p><strong>Date de transmission :</strong> {{date_reception}}</p>\n        </div>\n        \n        <p>Veuillez vous connecter au système GEC pour consulter ce courrier.</p>\n    </div>\n    <div class="footer">\n        <p>GEC - Système de Gestion du Courrier<br>\n        Secrétariat Général - République Démocratique du Congo</p>\n    </div>\n</body>\n</html>	GEC - Courrier Transmis\n\nUn courrier vous a été transmis par {{transmis_par}}.\n\nDétails du courrier :\n- Numéro d'accusé de réception : {{numero_accuse_reception}}\n- Type : {{type_courrier}}\n- Objet : {{objet}}\n- Expéditeur : {{expediteur}}\n- Date de transmission : {{date_reception}}\n\nConnectez-vous au système GEC pour consulter ce courrier.\n\nGEC - Système de Gestion du Courrier\nSecrétariat Général - République Démocratique du Congo	t	2025-08-30 02:50:28.628718	2025-08-30 02:50:28.628724	1	\N
\.


--
-- TOC entry 3579 (class 0 OID 24577)
-- Dependencies: 236
-- Data for Name: ip_block; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ip_block (id, ip_address, reason, blocked_at, expires_at, created_by, is_active) FROM stdin;
\.


--
-- TOC entry 3593 (class 0 OID 114689)
-- Dependencies: 250
-- Data for Name: ip_whitelist; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ip_whitelist (id, ip_address, description, created_at, created_by, is_active) FROM stdin;
\.


--
-- TOC entry 3577 (class 0 OID 16642)
-- Dependencies: 234
-- Data for Name: log_activite; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.log_activite (id, action, description, date_action, ip_address, utilisateur_id, courrier_id) FROM stdin;
46	AUDIT_LOGIN_SUCCESS	Successful login for user: sa.gec001	2025-09-03 00:21:26.978715	196.115.203.112	1	\N
47	CONNEXION	Connexion réussie pour sa.gec001	2025-09-03 00:21:27.178425	196.115.203.112, 10.83.10.210	1	\N
\.


--
-- TOC entry 3589 (class 0 OID 106497)
-- Dependencies: 246
-- Data for Name: migration_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.migration_log (id, migration_name, applied_at, version) FROM stdin;
\.


--
-- TOC entry 3581 (class 0 OID 32769)
-- Dependencies: 238
-- Data for Name: notification; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification (id, user_id, type_notification, titre, message, courrier_id, lu, date_creation, date_lecture) FROM stdin;
\.


--
-- TOC entry 3567 (class 0 OID 16532)
-- Dependencies: 224
-- Data for Name: parametres_systeme; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.parametres_systeme (id, nom_logiciel, logo_url, mode_numero_accuse, format_numero_accuse, adresse_organisme, telephone, email_contact, texte_footer, copyright_crypte, logo_pdf, titre_pdf, sous_titre_pdf, pays_pdf, copyright_text, date_modification, modifie_par_id, smtp_server, smtp_port, smtp_use_tls, smtp_username, smtp_password, appellation_departement, email_provider, notify_superadmin_new_mail, sendgrid_api_key, notification_templates, backup_settings, theme_settings, titre_responsable_structure) FROM stdin;
1	GEC - Mines RDC	\N	automatique	GEC-{year}-{counter:05d}	\N	\N	moa.myoneart@gmail.com	Système de Gestion Électronique du Courrier	wqkgMjAyNSBHRUMuIE1hZGUgd2l0aCDwn5KWIGFuZCDimJUgQnkgTU9BLURpZ2l0YWwgQWdlbmN5IExMQw==	\N	Ministère des Mines	Secrétariat Général	République Démocratique du Congo	© 2025 GEC. Made with 💖 and ☕ By MOA-Digital Agency LLC	2025-08-30 18:25:26.680791	1	monbusiness.pro	465	t	notif@monbusiness.pro	Pjjg8ldUOk9hNBwnIf0emrjY5zx0fGMhqsjuatMHC/M=	Divisions	sendgrid	f	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	\N	\N	\N	Directeur Général
\.


--
-- TOC entry 3569 (class 0 OID 16546)
-- Dependencies: 226
-- Data for Name: role; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role (id, nom, nom_affichage, description, couleur, icone, actif, modifiable, date_creation, date_modification, cree_par_id) FROM stdin;
1	super_admin	Super Administrateur	Accès complet au système avec toutes les permissions	bg-yellow-100 text-yellow-800	fas fa-crown	t	f	2025-08-29 15:51:27.395529	2025-08-29 15:51:27.395533	\N
2	admin	Administrateur	Gestion des utilisateurs et configuration système limitée	bg-blue-100 text-blue-800	fas fa-shield-alt	t	t	2025-08-29 15:51:27.395535	2025-08-29 15:51:27.395535	\N
3	user	Utilisateur	Accès de base pour enregistrer et consulter les courriers	bg-gray-100 text-gray-800	fas fa-user	t	t	2025-08-29 15:51:27.395536	2025-08-29 15:51:27.395536	\N
4	role_teste	Role teste	Role teste	bg-red-100 text-red-800	fas fa-key	t	t	2025-08-29 16:08:09.85872	2025-08-29 16:08:09.858724	1
\.


--
-- TOC entry 3573 (class 0 OID 16603)
-- Dependencies: 230
-- Data for Name: role_permission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_permission (id, role_id, permission_nom, date_creation, accorde_par_id) FROM stdin;
1	1	manage_users	2025-08-29 15:51:27.62797	\N
2	1	manage_roles	2025-08-29 15:51:27.627974	\N
3	1	manage_system_settings	2025-08-29 15:51:27.627975	\N
4	1	view_all_logs	2025-08-29 15:51:27.627975	\N
5	1	manage_statuses	2025-08-29 15:51:27.627976	\N
6	1	manage_departments	2025-08-29 15:51:27.627977	\N
7	1	register_mail	2025-08-29 15:51:27.627977	\N
8	1	view_mail	2025-08-29 15:51:27.627978	\N
9	1	search_mail	2025-08-29 15:51:27.627978	\N
10	1	export_data	2025-08-29 15:51:27.627979	\N
11	1	delete_mail	2025-08-29 15:51:27.627979	\N
12	1	view_trash	2025-08-29 15:51:27.62798	\N
13	1	restore_mail	2025-08-29 15:51:27.62798	\N
14	1	view_all	2025-08-29 15:51:27.627981	\N
15	1	edit_all	2025-08-29 15:51:27.627981	\N
16	1	read_all_mail	2025-08-29 15:51:27.627982	\N
17	1	manage_updates	2025-08-29 15:51:27.627982	\N
18	1	manage_backup	2025-08-29 15:51:27.627983	\N
19	2	manage_statuses	2025-08-29 15:51:27.707806	\N
20	2	register_mail	2025-08-29 15:51:27.707809	\N
21	2	view_mail	2025-08-29 15:51:27.70781	\N
22	2	search_mail	2025-08-29 15:51:27.70781	\N
23	2	export_data	2025-08-29 15:51:27.707811	\N
24	2	manage_system_settings	2025-08-29 15:51:27.707811	\N
25	2	view_department	2025-08-29 15:51:27.707812	\N
26	2	edit_department	2025-08-29 15:51:27.707812	\N
27	2	read_department_mail	2025-08-29 15:51:27.707812	\N
28	3	register_mail	2025-08-29 15:51:27.790274	\N
29	3	view_mail	2025-08-29 15:51:27.790277	\N
30	3	search_mail	2025-08-29 15:51:27.790278	\N
31	3	export_data	2025-08-29 15:51:27.790278	\N
32	3	view_own	2025-08-29 15:51:27.790279	\N
33	3	edit_own	2025-08-29 15:51:27.790279	\N
34	3	read_own_mail	2025-08-29 15:51:27.79028	\N
35	4	manage_security_settings	2025-08-29 16:08:09.904424	1
36	4	manage_statuses	2025-08-29 16:08:09.904432	1
37	4	register_mail	2025-08-29 16:08:09.904433	1
38	4	view_mail	2025-08-29 16:08:09.904433	1
39	4	search_mail	2025-08-29 16:08:09.904434	1
40	4	export_data	2025-08-29 16:08:09.904435	1
41	4	delete_mail	2025-08-29 16:08:09.904435	1
42	4	view_trash	2025-08-29 16:08:09.904436	1
43	4	restore_mail	2025-08-29 16:08:09.904436	1
44	4	read_all_mail	2025-08-29 16:08:09.904437	1
45	4	read_department_mail	2025-08-29 16:08:09.904438	1
46	4	read_own_mail	2025-08-29 16:08:09.904438	1
47	4	manage_updates	2025-08-29 16:08:09.904439	1
48	4	manage_backup	2025-08-29 16:08:09.904439	1
49	1	manage_email_templates	\N	\N
50	2	manage_email_templates	\N	\N
\.


--
-- TOC entry 3563 (class 0 OID 16507)
-- Dependencies: 220
-- Data for Name: statut_courrier; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.statut_courrier (id, nom, description, couleur, actif, ordre, date_creation) FROM stdin;
1	RECU	Courrier reçu	bg-blue-100 text-blue-800	t	1	2025-08-29 15:51:26.902202
2	EN_COURS	En cours de traitement	bg-yellow-100 text-yellow-800	t	2	2025-08-29 15:51:26.976759
3	TRAITE	Traité	bg-green-100 text-green-800	t	3	2025-08-29 15:51:27.052542
4	ARCHIVE	Archivé	bg-gray-100 text-gray-800	t	4	2025-08-29 15:51:27.128018
5	URGENT	Urgent	bg-red-100 text-red-800	t	0	2025-08-29 15:51:27.202978
\.


--
-- TOC entry 3591 (class 0 OID 106515)
-- Dependencies: 248
-- Data for Name: system_health; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_health (id, check_name, status, last_check, details) FROM stdin;
\.


--
-- TOC entry 3565 (class 0 OID 16516)
-- Dependencies: 222
-- Data for Name: type_courrier_sortant; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.type_courrier_sortant (id, nom, description, actif, ordre_affichage, date_creation, cree_par_id) FROM stdin;
1	Note circulaire	Note circulaire à diffusion large	t	1	2025-08-29 15:51:28.180194	\N
2	Note télégramme	Note télégramme urgente	t	2	2025-08-29 15:51:28.180198	\N
3	Lettre officielle	Lettre officielle standard	t	3	2025-08-29 15:51:28.180198	\N
4	Mémorandum	Mémorandum interne	t	4	2025-08-29 15:51:28.180199	\N
5	Convocation	Convocation à une réunion ou événement	t	5	2025-08-29 15:51:28.1802	\N
6	Rapport	Rapport officiel	t	6	2025-08-29 15:51:28.1802	\N
7	Note de service	Note de service interne	t	7	2025-08-29 15:51:28.180201	\N
8	Autre	Autre type de courrier sortant	t	99	2025-08-29 15:51:28.180202	\N
\.


--
-- TOC entry 3561 (class 0 OID 16489)
-- Dependencies: 218
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."user" (id, username, email, nom_complet, password_hash, date_creation, actif, role, langue, photo_profile, departement_id, matricule, fonction, email_encrypted, nom_complet_encrypted, matricule_encrypted, fonction_encrypted, password_hash_encrypted) FROM stdin;
1	sa.gec001	admin@mines.gov.cd	Administrateur Système	scrypt:32768:8:1$hYRECTy7aQ0EvOcS$a605aa462ff9930d86dcdd5ada0f8eaf99e561f7292d458f88882d1281f88cc2a683f173506194583e4a3873f21c600dbc5ca82ba45d3a4faaafcf785ff1933d	2025-08-29 15:51:26.500423	t	super_admin	fr	\N	\N	\N	\N	\N	\N	\N	\N	\N
2	superadmin2	moa.myoneart@gmail.com	Administrateur 2	scrypt:32768:8:1$D77EXYSIg8cBiBkT$eafc2ccf4400d573c6c2ddb79431ad3848524fbfdad28a40e52aeb72a3f49f0b3cb8906bba829771d7b76a137575d1ee1313f4728685404fe2480482f643892d	2025-08-30 11:00:32.905697	t	admin	fr	\N	1	\N	\N	\N	\N	\N	\N	\N
3	usertest	aisancekalonji@gmail.com	Kalonji	scrypt:32768:8:1$C2Y3FdD1hSK6furM$15aeb7a65d8ea3af7748d8e1eee575d6662c0954620f74d03841d6414a33447771f5dcb66e9d1b5f3caad4ad969e473c75bc2b39de3c3e7c4d6be8c1dc7003ce	2025-08-30 11:01:18.012017	t	user	fr	\N	1	\N	\N	\N	\N	\N	\N	\N
\.


--
-- TOC entry 3618 (class 0 OID 0)
-- Dependencies: 239
-- Name: courrier_comment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.courrier_comment_id_seq', 1, true);


--
-- TOC entry 3619 (class 0 OID 0)
-- Dependencies: 241
-- Name: courrier_forward_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.courrier_forward_id_seq', 1, false);


--
-- TOC entry 3620 (class 0 OID 0)
-- Dependencies: 227
-- Name: courrier_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.courrier_id_seq', 1, false);


--
-- TOC entry 3621 (class 0 OID 0)
-- Dependencies: 231
-- Name: courrier_modification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.courrier_modification_id_seq', 1, false);


--
-- TOC entry 3622 (class 0 OID 0)
-- Dependencies: 215
-- Name: departement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.departement_id_seq', 5, true);


--
-- TOC entry 3623 (class 0 OID 0)
-- Dependencies: 243
-- Name: email_template_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.email_template_id_seq', 2, true);


--
-- TOC entry 3624 (class 0 OID 0)
-- Dependencies: 235
-- Name: ip_block_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ip_block_id_seq', 1, false);


--
-- TOC entry 3625 (class 0 OID 0)
-- Dependencies: 249
-- Name: ip_whitelist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ip_whitelist_id_seq', 1, false);


--
-- TOC entry 3626 (class 0 OID 0)
-- Dependencies: 233
-- Name: log_activite_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.log_activite_id_seq', 47, true);


--
-- TOC entry 3627 (class 0 OID 0)
-- Dependencies: 245
-- Name: migration_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.migration_log_id_seq', 1, false);


--
-- TOC entry 3628 (class 0 OID 0)
-- Dependencies: 237
-- Name: notification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notification_id_seq', 1, true);


--
-- TOC entry 3629 (class 0 OID 0)
-- Dependencies: 223
-- Name: parametres_systeme_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.parametres_systeme_id_seq', 1, true);


--
-- TOC entry 3630 (class 0 OID 0)
-- Dependencies: 225
-- Name: role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.role_id_seq', 4, true);


--
-- TOC entry 3631 (class 0 OID 0)
-- Dependencies: 229
-- Name: role_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.role_permission_id_seq', 50, true);


--
-- TOC entry 3632 (class 0 OID 0)
-- Dependencies: 219
-- Name: statut_courrier_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.statut_courrier_id_seq', 5, true);


--
-- TOC entry 3633 (class 0 OID 0)
-- Dependencies: 247
-- Name: system_health_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.system_health_id_seq', 1, false);


--
-- TOC entry 3634 (class 0 OID 0)
-- Dependencies: 221
-- Name: type_courrier_sortant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.type_courrier_sortant_id_seq', 8, true);


--
-- TOC entry 3635 (class 0 OID 0)
-- Dependencies: 217
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_id_seq', 3, true);


--
-- TOC entry 3363 (class 2606 OID 32800)
-- Name: courrier_comment courrier_comment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courrier_comment
    ADD CONSTRAINT courrier_comment_pkey PRIMARY KEY (id);


--
-- TOC entry 3370 (class 2606 OID 32829)
-- Name: courrier_forward courrier_forward_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courrier_forward
    ADD CONSTRAINT courrier_forward_pkey PRIMARY KEY (id);


--
-- TOC entry 3339 (class 2606 OID 16627)
-- Name: courrier_modification courrier_modification_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courrier_modification
    ADD CONSTRAINT courrier_modification_pkey PRIMARY KEY (id);


--
-- TOC entry 3323 (class 2606 OID 16569)
-- Name: courrier courrier_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courrier
    ADD CONSTRAINT courrier_pkey PRIMARY KEY (id);


--
-- TOC entry 3292 (class 2606 OID 16487)
-- Name: departement departement_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departement
    ADD CONSTRAINT departement_code_key UNIQUE (code);


--
-- TOC entry 3294 (class 2606 OID 16485)
-- Name: departement departement_nom_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departement
    ADD CONSTRAINT departement_nom_key UNIQUE (nom);


--
-- TOC entry 3296 (class 2606 OID 16483)
-- Name: departement departement_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departement
    ADD CONSTRAINT departement_pkey PRIMARY KEY (id);


--
-- TOC entry 3378 (class 2606 OID 65544)
-- Name: email_template email_template_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_template
    ADD CONSTRAINT email_template_pkey PRIMARY KEY (id);


--
-- TOC entry 3350 (class 2606 OID 24582)
-- Name: ip_block ip_block_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ip_block
    ADD CONSTRAINT ip_block_pkey PRIMARY KEY (id);


--
-- TOC entry 3386 (class 2606 OID 114694)
-- Name: ip_whitelist ip_whitelist_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ip_whitelist
    ADD CONSTRAINT ip_whitelist_pkey PRIMARY KEY (id);


--
-- TOC entry 3348 (class 2606 OID 16649)
-- Name: log_activite log_activite_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.log_activite
    ADD CONSTRAINT log_activite_pkey PRIMARY KEY (id);


--
-- TOC entry 3382 (class 2606 OID 106503)
-- Name: migration_log migration_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migration_log
    ADD CONSTRAINT migration_log_pkey PRIMARY KEY (id);


--
-- TOC entry 3361 (class 2606 OID 32776)
-- Name: notification notification_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT notification_pkey PRIMARY KEY (id);


--
-- TOC entry 3317 (class 2606 OID 16539)
-- Name: parametres_systeme parametres_systeme_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parametres_systeme
    ADD CONSTRAINT parametres_systeme_pkey PRIMARY KEY (id);


--
-- TOC entry 3319 (class 2606 OID 16555)
-- Name: role role_nom_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT role_nom_key UNIQUE (nom);


--
-- TOC entry 3337 (class 2606 OID 16608)
-- Name: role_permission role_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permission
    ADD CONSTRAINT role_permission_pkey PRIMARY KEY (id);


--
-- TOC entry 3321 (class 2606 OID 16553)
-- Name: role role_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT role_pkey PRIMARY KEY (id);


--
-- TOC entry 3309 (class 2606 OID 16514)
-- Name: statut_courrier statut_courrier_nom_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.statut_courrier
    ADD CONSTRAINT statut_courrier_nom_key UNIQUE (nom);


--
-- TOC entry 3311 (class 2606 OID 16512)
-- Name: statut_courrier statut_courrier_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.statut_courrier
    ADD CONSTRAINT statut_courrier_pkey PRIMARY KEY (id);


--
-- TOC entry 3384 (class 2606 OID 106523)
-- Name: system_health system_health_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_health
    ADD CONSTRAINT system_health_pkey PRIMARY KEY (id);


--
-- TOC entry 3313 (class 2606 OID 16525)
-- Name: type_courrier_sortant type_courrier_sortant_nom_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.type_courrier_sortant
    ADD CONSTRAINT type_courrier_sortant_nom_key UNIQUE (nom);


--
-- TOC entry 3315 (class 2606 OID 16523)
-- Name: type_courrier_sortant type_courrier_sortant_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.type_courrier_sortant
    ADD CONSTRAINT type_courrier_sortant_pkey PRIMARY KEY (id);


--
-- TOC entry 3380 (class 2606 OID 65546)
-- Name: email_template unique_template_lang; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_template
    ADD CONSTRAINT unique_template_lang UNIQUE (type_template, langue);


--
-- TOC entry 3305 (class 2606 OID 16498)
-- Name: user user_matricule_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_matricule_key UNIQUE (matricule);


--
-- TOC entry 3307 (class 2606 OID 16496)
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- TOC entry 3364 (class 1259 OID 32819)
-- Name: ix_courrier_comment_actif; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_courrier_comment_actif ON public.courrier_comment USING btree (actif);


--
-- TOC entry 3365 (class 1259 OID 32816)
-- Name: ix_courrier_comment_courrier_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_courrier_comment_courrier_id ON public.courrier_comment USING btree (courrier_id);


--
-- TOC entry 3366 (class 1259 OID 32818)
-- Name: ix_courrier_comment_date_creation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_courrier_comment_date_creation ON public.courrier_comment USING btree (date_creation);


--
-- TOC entry 3367 (class 1259 OID 32820)
-- Name: ix_courrier_comment_type_comment; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_courrier_comment_type_comment ON public.courrier_comment USING btree (type_comment);


--
-- TOC entry 3368 (class 1259 OID 32817)
-- Name: ix_courrier_comment_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_courrier_comment_user_id ON public.courrier_comment USING btree (user_id);


--
-- TOC entry 3324 (class 1259 OID 16596)
-- Name: ix_courrier_date_enregistrement; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_courrier_date_enregistrement ON public.courrier USING btree (date_enregistrement);


--
-- TOC entry 3325 (class 1259 OID 16600)
-- Name: ix_courrier_date_modification_statut; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_courrier_date_modification_statut ON public.courrier USING btree (date_modification_statut);


--
-- TOC entry 3326 (class 1259 OID 16594)
-- Name: ix_courrier_date_redaction; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_courrier_date_redaction ON public.courrier USING btree (date_redaction);


--
-- TOC entry 3327 (class 1259 OID 16598)
-- Name: ix_courrier_destinataire; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_courrier_destinataire ON public.courrier USING btree (destinataire);


--
-- TOC entry 3328 (class 1259 OID 16593)
-- Name: ix_courrier_expediteur; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_courrier_expediteur ON public.courrier USING btree (expediteur);


--
-- TOC entry 3329 (class 1259 OID 16590)
-- Name: ix_courrier_fichier_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_courrier_fichier_type ON public.courrier USING btree (fichier_type);


--
-- TOC entry 3371 (class 1259 OID 32847)
-- Name: ix_courrier_forward_courrier_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_courrier_forward_courrier_id ON public.courrier_forward USING btree (courrier_id);


--
-- TOC entry 3372 (class 1259 OID 32848)
-- Name: ix_courrier_forward_date_transmission; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_courrier_forward_date_transmission ON public.courrier_forward USING btree (date_transmission);


--
-- TOC entry 3373 (class 1259 OID 32845)
-- Name: ix_courrier_forward_email_sent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_courrier_forward_email_sent ON public.courrier_forward USING btree (email_sent);


--
-- TOC entry 3374 (class 1259 OID 32849)
-- Name: ix_courrier_forward_forwarded_by_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_courrier_forward_forwarded_by_id ON public.courrier_forward USING btree (forwarded_by_id);


--
-- TOC entry 3375 (class 1259 OID 32850)
-- Name: ix_courrier_forward_forwarded_to_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_courrier_forward_forwarded_to_id ON public.courrier_forward USING btree (forwarded_to_id);


--
-- TOC entry 3376 (class 1259 OID 32846)
-- Name: ix_courrier_forward_lu; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_courrier_forward_lu ON public.courrier_forward USING btree (lu);


--
-- TOC entry 3330 (class 1259 OID 16592)
-- Name: ix_courrier_is_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_courrier_is_deleted ON public.courrier USING btree (is_deleted);


--
-- TOC entry 3340 (class 1259 OID 16639)
-- Name: ix_courrier_modification_courrier_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_courrier_modification_courrier_id ON public.courrier_modification USING btree (courrier_id);


--
-- TOC entry 3341 (class 1259 OID 16638)
-- Name: ix_courrier_modification_date_modification; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_courrier_modification_date_modification ON public.courrier_modification USING btree (date_modification);


--
-- TOC entry 3342 (class 1259 OID 16640)
-- Name: ix_courrier_modification_utilisateur_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_courrier_modification_utilisateur_id ON public.courrier_modification USING btree (utilisateur_id);


--
-- TOC entry 3331 (class 1259 OID 16599)
-- Name: ix_courrier_numero_accuse_reception; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_courrier_numero_accuse_reception ON public.courrier USING btree (numero_accuse_reception);


--
-- TOC entry 3332 (class 1259 OID 16597)
-- Name: ix_courrier_numero_reference; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_courrier_numero_reference ON public.courrier USING btree (numero_reference);


--
-- TOC entry 3333 (class 1259 OID 16591)
-- Name: ix_courrier_statut; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_courrier_statut ON public.courrier USING btree (statut);


--
-- TOC entry 3334 (class 1259 OID 16601)
-- Name: ix_courrier_type_courrier; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_courrier_type_courrier ON public.courrier USING btree (type_courrier);


--
-- TOC entry 3335 (class 1259 OID 16595)
-- Name: ix_courrier_type_courrier_sortant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_courrier_type_courrier_sortant_id ON public.courrier USING btree (type_courrier_sortant_id);


--
-- TOC entry 3351 (class 1259 OID 24585)
-- Name: ix_ip_block_blocked_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ip_block_blocked_at ON public.ip_block USING btree (blocked_at);


--
-- TOC entry 3352 (class 1259 OID 24586)
-- Name: ix_ip_block_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ip_block_expires_at ON public.ip_block USING btree (expires_at);


--
-- TOC entry 3353 (class 1259 OID 24583)
-- Name: ix_ip_block_ip_address; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_ip_block_ip_address ON public.ip_block USING btree (ip_address);


--
-- TOC entry 3354 (class 1259 OID 24584)
-- Name: ix_ip_block_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ip_block_is_active ON public.ip_block USING btree (is_active);


--
-- TOC entry 3387 (class 1259 OID 114695)
-- Name: ix_ip_whitelist_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ip_whitelist_created_at ON public.ip_whitelist USING btree (created_at);


--
-- TOC entry 3388 (class 1259 OID 114696)
-- Name: ix_ip_whitelist_ip_address; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_ip_whitelist_ip_address ON public.ip_whitelist USING btree (ip_address);


--
-- TOC entry 3389 (class 1259 OID 114697)
-- Name: ix_ip_whitelist_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ip_whitelist_is_active ON public.ip_whitelist USING btree (is_active);


--
-- TOC entry 3343 (class 1259 OID 16663)
-- Name: ix_log_activite_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_log_activite_action ON public.log_activite USING btree (action);


--
-- TOC entry 3344 (class 1259 OID 16660)
-- Name: ix_log_activite_courrier_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_log_activite_courrier_id ON public.log_activite USING btree (courrier_id);


--
-- TOC entry 3345 (class 1259 OID 16661)
-- Name: ix_log_activite_date_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_log_activite_date_action ON public.log_activite USING btree (date_action);


--
-- TOC entry 3346 (class 1259 OID 16662)
-- Name: ix_log_activite_utilisateur_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_log_activite_utilisateur_id ON public.log_activite USING btree (utilisateur_id);


--
-- TOC entry 3355 (class 1259 OID 32788)
-- Name: ix_notification_courrier_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notification_courrier_id ON public.notification USING btree (courrier_id);


--
-- TOC entry 3356 (class 1259 OID 32791)
-- Name: ix_notification_date_creation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notification_date_creation ON public.notification USING btree (date_creation);


--
-- TOC entry 3357 (class 1259 OID 32787)
-- Name: ix_notification_lu; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notification_lu ON public.notification USING btree (lu);


--
-- TOC entry 3358 (class 1259 OID 32789)
-- Name: ix_notification_type_notification; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notification_type_notification ON public.notification USING btree (type_notification);


--
-- TOC entry 3359 (class 1259 OID 32790)
-- Name: ix_notification_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notification_user_id ON public.notification USING btree (user_id);


--
-- TOC entry 3297 (class 1259 OID 16502)
-- Name: ix_user_actif; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_actif ON public."user" USING btree (actif);


--
-- TOC entry 3298 (class 1259 OID 16503)
-- Name: ix_user_date_creation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_date_creation ON public."user" USING btree (date_creation);


--
-- TOC entry 3299 (class 1259 OID 16504)
-- Name: ix_user_departement_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_departement_id ON public."user" USING btree (departement_id);


--
-- TOC entry 3300 (class 1259 OID 16501)
-- Name: ix_user_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_user_email ON public."user" USING btree (email);


--
-- TOC entry 3301 (class 1259 OID 16505)
-- Name: ix_user_nom_complet; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_nom_complet ON public."user" USING btree (nom_complet);


--
-- TOC entry 3302 (class 1259 OID 16500)
-- Name: ix_user_role; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_role ON public."user" USING btree (role);


--
-- TOC entry 3303 (class 1259 OID 16499)
-- Name: ix_user_username; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_user_username ON public."user" USING btree (username);


--
-- TOC entry 3407 (class 2606 OID 32801)
-- Name: courrier_comment courrier_comment_courrier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courrier_comment
    ADD CONSTRAINT courrier_comment_courrier_id_fkey FOREIGN KEY (courrier_id) REFERENCES public.courrier(id);


--
-- TOC entry 3408 (class 2606 OID 32811)
-- Name: courrier_comment courrier_comment_modifie_par_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courrier_comment
    ADD CONSTRAINT courrier_comment_modifie_par_id_fkey FOREIGN KEY (modifie_par_id) REFERENCES public."user"(id);


--
-- TOC entry 3409 (class 2606 OID 32806)
-- Name: courrier_comment courrier_comment_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courrier_comment
    ADD CONSTRAINT courrier_comment_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- TOC entry 3395 (class 2606 OID 16575)
-- Name: courrier courrier_deleted_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courrier
    ADD CONSTRAINT courrier_deleted_by_id_fkey FOREIGN KEY (deleted_by_id) REFERENCES public."user"(id);


--
-- TOC entry 3410 (class 2606 OID 32830)
-- Name: courrier_forward courrier_forward_courrier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courrier_forward
    ADD CONSTRAINT courrier_forward_courrier_id_fkey FOREIGN KEY (courrier_id) REFERENCES public.courrier(id);


--
-- TOC entry 3411 (class 2606 OID 32835)
-- Name: courrier_forward courrier_forward_forwarded_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courrier_forward
    ADD CONSTRAINT courrier_forward_forwarded_by_id_fkey FOREIGN KEY (forwarded_by_id) REFERENCES public."user"(id);


--
-- TOC entry 3412 (class 2606 OID 32840)
-- Name: courrier_forward courrier_forward_forwarded_to_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courrier_forward
    ADD CONSTRAINT courrier_forward_forwarded_to_id_fkey FOREIGN KEY (forwarded_to_id) REFERENCES public."user"(id);


--
-- TOC entry 3401 (class 2606 OID 16628)
-- Name: courrier_modification courrier_modification_courrier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courrier_modification
    ADD CONSTRAINT courrier_modification_courrier_id_fkey FOREIGN KEY (courrier_id) REFERENCES public.courrier(id);


--
-- TOC entry 3402 (class 2606 OID 16633)
-- Name: courrier_modification courrier_modification_utilisateur_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courrier_modification
    ADD CONSTRAINT courrier_modification_utilisateur_id_fkey FOREIGN KEY (utilisateur_id) REFERENCES public."user"(id);


--
-- TOC entry 3396 (class 2606 OID 16585)
-- Name: courrier courrier_modifie_par_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courrier
    ADD CONSTRAINT courrier_modifie_par_id_fkey FOREIGN KEY (modifie_par_id) REFERENCES public."user"(id);


--
-- TOC entry 3397 (class 2606 OID 16570)
-- Name: courrier courrier_type_courrier_sortant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courrier
    ADD CONSTRAINT courrier_type_courrier_sortant_id_fkey FOREIGN KEY (type_courrier_sortant_id) REFERENCES public.type_courrier_sortant(id);


--
-- TOC entry 3398 (class 2606 OID 16580)
-- Name: courrier courrier_utilisateur_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courrier
    ADD CONSTRAINT courrier_utilisateur_id_fkey FOREIGN KEY (utilisateur_id) REFERENCES public."user"(id);


--
-- TOC entry 3390 (class 2606 OID 16664)
-- Name: departement departement_chef_departement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departement
    ADD CONSTRAINT departement_chef_departement_id_fkey FOREIGN KEY (chef_departement_id) REFERENCES public."user"(id);


--
-- TOC entry 3413 (class 2606 OID 65547)
-- Name: email_template email_template_cree_par_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_template
    ADD CONSTRAINT email_template_cree_par_id_fkey FOREIGN KEY (cree_par_id) REFERENCES public."user"(id);


--
-- TOC entry 3414 (class 2606 OID 65552)
-- Name: email_template email_template_modifie_par_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_template
    ADD CONSTRAINT email_template_modifie_par_id_fkey FOREIGN KEY (modifie_par_id) REFERENCES public."user"(id);


--
-- TOC entry 3403 (class 2606 OID 16655)
-- Name: log_activite log_activite_courrier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.log_activite
    ADD CONSTRAINT log_activite_courrier_id_fkey FOREIGN KEY (courrier_id) REFERENCES public.courrier(id);


--
-- TOC entry 3404 (class 2606 OID 16650)
-- Name: log_activite log_activite_utilisateur_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.log_activite
    ADD CONSTRAINT log_activite_utilisateur_id_fkey FOREIGN KEY (utilisateur_id) REFERENCES public."user"(id);


--
-- TOC entry 3405 (class 2606 OID 32782)
-- Name: notification notification_courrier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT notification_courrier_id_fkey FOREIGN KEY (courrier_id) REFERENCES public.courrier(id);


--
-- TOC entry 3406 (class 2606 OID 32777)
-- Name: notification notification_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT notification_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- TOC entry 3393 (class 2606 OID 16540)
-- Name: parametres_systeme parametres_systeme_modifie_par_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parametres_systeme
    ADD CONSTRAINT parametres_systeme_modifie_par_id_fkey FOREIGN KEY (modifie_par_id) REFERENCES public."user"(id);


--
-- TOC entry 3394 (class 2606 OID 16556)
-- Name: role role_cree_par_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT role_cree_par_id_fkey FOREIGN KEY (cree_par_id) REFERENCES public."user"(id);


--
-- TOC entry 3399 (class 2606 OID 16614)
-- Name: role_permission role_permission_accorde_par_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permission
    ADD CONSTRAINT role_permission_accorde_par_id_fkey FOREIGN KEY (accorde_par_id) REFERENCES public."user"(id);


--
-- TOC entry 3400 (class 2606 OID 16609)
-- Name: role_permission role_permission_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permission
    ADD CONSTRAINT role_permission_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.role(id);


--
-- TOC entry 3392 (class 2606 OID 16526)
-- Name: type_courrier_sortant type_courrier_sortant_cree_par_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.type_courrier_sortant
    ADD CONSTRAINT type_courrier_sortant_cree_par_id_fkey FOREIGN KEY (cree_par_id) REFERENCES public."user"(id);


--
-- TOC entry 3391 (class 2606 OID 16669)
-- Name: user user_departement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_departement_id_fkey FOREIGN KEY (departement_id) REFERENCES public.departement(id);


-- Completed on 2025-09-03 01:43:38 UTC

--
-- PostgreSQL database dump complete
--

